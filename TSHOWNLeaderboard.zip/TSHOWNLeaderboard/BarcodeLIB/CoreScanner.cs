﻿using CoreScanner;
using log4net;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml;

namespace TSHOWNLeaderboard.BarcodeLIB
{
    class CoreScanner
    {
        public static ILog log = LogManager.GetLogger("log");
        public static string ScanData { get; set; }
        public static bool bCoreScannerDriverStatus { get; set; }
        public static int status;
        public static string inXML;
        public static string outXML;
        public static int opCode;
        public static CCoreScanner cCoreScanner = new CCoreScanner();
        public static void checkForCoreScannerProcess()
        {
            Process[] pname = Process.GetProcessesByName("CoreScanner");
            if (pname.Length == 0)
            {
                bCoreScannerDriverStatus = false;
            }
            else
            {
                bCoreScannerDriverStatus = true;
            }
        }

        public static void initiateCoreScanners()
        {
            cCoreScanner.BarcodeEvent += new _ICoreScannerEvents_BarcodeEventEventHandler(OnBarcodeEvent);
            cCoreScanner.PNPEvent += new _ICoreScannerEvents_PNPEventEventHandler(OnPNPEvent);
            cCoreScanner.CommandResponseEvent += new _ICoreScannerEvents_CommandResponseEventEventHandler(OnCommandResponseEvent);
            cCoreScanner.IOEvent += new _ICoreScannerEvents_IOEventEventHandler(OnIOEvent);
            cCoreScanner.ScanRMDEvent += new _ICoreScannerEvents_ScanRMDEventEventHandler(OnScanRMDEvent);

            int[] connectedScannerIDList = new int[255];
            short[] scannerType = new short[1];
            short numOfScanners = 1;
            short numofScannerTypes = 1;
            XmlDocument xDoc = new XmlDocument();
            XmlNodeList xNodeItems;

            int intBeep;

            scannerType[0] = 6;
            opCode = 1001;
            outXML = null;
            inXML = "<inArgs>" + "<cmdArgs>" + "<arg-int>2</arg-int>" + "<arg-int>1,16</arg-int>" + "</cmdArgs>" + "</inArgs>";

            try
            {
                cCoreScanner.Open(0, scannerType, numofScannerTypes, out status);
                cCoreScanner.ExecCommand(opCode, ref inXML, out outXML, out status);

                opCode = 6000;
                intBeep = 24;

                cCoreScanner.GetScanners(out numOfScanners, connectedScannerIDList, out outXML, out status);
                xDoc.LoadXml(outXML);

                xNodeItems = xDoc.DocumentElement.GetElementsByTagName("scannerID");
                foreach (XmlNode node in xNodeItems)
                {
                    inXML = "<inArgs>" + "<scannerID>" + node.InnerText + "</scannerID>" + "<cmdArgs>" + "<arg-int>" + intBeep + "</arg-int>" + "</cmdArgs>" + "</inArgs>";
                    cCoreScanner.ExecCommand(opCode, ref inXML, out outXML, out status);
                }
                Debug.WriteLine("Scanners Initiated");
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
        }

        public static void OnBarcodeEvent(short eventType, ref string pscanData)
        {
            ProductionValidationEntities DB = new ProductionValidationEntities();
            //XmlDocument xDoc = new XmlDocument();
            string BarcodeData = "";
            string sBarcodeSerial = "";
            //long BarcodeSerial = 0;
            //string BarcodeTask = "";
            //string ScanData = "";
            string[] DataArray;
            string[] ScanDataArray;
            StringBuilder data = new StringBuilder();

            ScanDataArray = Regex.Split(pscanData, "\r\n");
            BarcodeData = Regex.Match(ScanDataArray[9], @"\>([^)]*)\<").Groups[1].Value;
            sBarcodeSerial = Regex.Match(ScanDataArray[6], @"\>([^)]*)\<").Groups[1].Value.Trim();
            //BarcodeSerial = Convert.ToInt64(sBarcodeSerial);
            //BarcodeTask = Global.BarcodeScanners.Where(w => w.Serial == BarcodeSerial).Select(x => x.Task).FirstOrDefault();
            DataArray = BarcodeData.Split(' ');
            foreach (string item in DataArray)
            {
                if (item != "")
                {
                    data.Append(Convert.ToChar(Convert.ToUInt32(item, 16)));
                }
            }

            global.scannedValue = data.ToString();
        }

        public static void OnPNPEvent(short eventType, ref string pscanData)
        {
            //MessageBox.Show("**********PNP**********");
        }

        public static void OnCommandResponseEvent(short eventType, ref string pscanData)
        {
            // MessageBox.Show("**********CommandResponse**********");
        }

        public static void OnIOEvent(short eventType, byte pscanData)
        {
            // MessageBox.Show("**********IO**********");
        }

        public static void OnScanRMDEvent(short eventType, ref string pscanData)
        {
            // MessageBox.Show("**********ScanRMD**********");
        }

        public static void ReconnectCoreScanners()
        {
            //CCoreScanner cCoreScanner = new CCoreScanner();
            //cCoreScanner.BarcodeEvent -= new _ICoreScannerEvents_BarcodeEventEventHandler(OnBarcodeEvent);
            //cCoreScanner.BarcodeEvent += new _ICoreScannerEvents_BarcodeEventEventHandler(OnBarcodeEvent);
            //cCoreScanner.PNPEvent += new _ICoreScannerEvents_PNPEventEventHandler(OnPNPEvent);
            //cCoreScanner.CommandResponseEvent += new _ICoreScannerEvents_CommandResponseEventEventHandler(OnCommandResponseEvent);
            //cCoreScanner.IOEvent += new _ICoreScannerEvents_IOEventEventHandler(OnIOEvent);
            //cCoreScanner.ScanRMDEvent += new _ICoreScannerEvents_ScanRMDEventEventHandler(OnScanRMDEvent);

            int[] connectedScannerIDList = new int[255];
            short[] scannerType = new short[1];
            short numOfScanners = 1;
            short numofScannerTypes = 1;
            XmlDocument xDoc = new XmlDocument();
            XmlNodeList xNodeItems;

            int intBeep;

            scannerType[0] = 6;
            opCode = 1001;
            outXML = null;
            inXML = "<inArgs>" + "<cmdArgs>" + "<arg-int>2</arg-int>" + "<arg-int>1,16</arg-int>" + "</cmdArgs>" + "</inArgs>";

            try
            {
                cCoreScanner.Open(0, scannerType, numofScannerTypes, out status);
                cCoreScanner.ExecCommand(opCode, ref inXML, out outXML, out status);

                opCode = 6000;
                intBeep = 24;

                cCoreScanner.GetScanners(out numOfScanners, connectedScannerIDList, out outXML, out status);
                xDoc.LoadXml(outXML);

                xNodeItems = xDoc.DocumentElement.GetElementsByTagName("scannerID");
                foreach (XmlNode node in xNodeItems)
                {
                    inXML = "<inArgs>" + "<scannerID>" + node.InnerText + "</scannerID>" + "<cmdArgs>" + "<arg-int>" + intBeep + "</arg-int>" + "</cmdArgs>" + "</inArgs>";
                    //inXML = "<inArgs>" + "<scannerID>" + node.InnerText + "</scannerID>" + "<cmdArgs>" + "<arg-int></arg-int>" + "</cmdArgs>" + "</inArgs>";
                    cCoreScanner.ExecCommand(opCode, ref inXML, out outXML, out status);
                }
                Debug.WriteLine("Scanners Initiated....again");
            }
            catch (Exception ex)
            {
                log.Error(ex);
            }
        }
    }
}
