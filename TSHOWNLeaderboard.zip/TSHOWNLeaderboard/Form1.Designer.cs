﻿namespace TSHOWNLeaderboard
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tmrClock = new System.Windows.Forms.Timer(this.components);
            this.tmrNetStatus = new System.Windows.Forms.Timer(this.components);
            this.lblCurrentDateTime = new System.Windows.Forms.Label();
            this.tmrNUMATO = new System.Windows.Forms.Timer(this.components);
            this.DGVProduction = new System.Windows.Forms.DataGridView();
            this.pnlTime = new System.Windows.Forms.Panel();
            this.pnlGoal = new System.Windows.Forms.Panel();
            this.lblGoalLabel = new System.Windows.Forms.Label();
            this.lblGoal = new System.Windows.Forms.Label();
            this.pnlBuilt = new System.Windows.Forms.Panel();
            this.lblBuiltLabel = new System.Windows.Forms.Label();
            this.lblBuilt = new System.Windows.Forms.Label();
            this.pnlDifference = new System.Windows.Forms.Panel();
            this.lblDifferenceLabel = new System.Windows.Forms.Label();
            this.lblDifference = new System.Windows.Forms.Label();
            this.tmrWindowFile = new System.Windows.Forms.Timer(this.components);
            this.tmrCountFile = new System.Windows.Forms.Timer(this.components);
            this.lblSelectedLine = new System.Windows.Forms.Label();
            this.tmrReadFiles = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.DGVProduction)).BeginInit();
            this.pnlTime.SuspendLayout();
            this.pnlGoal.SuspendLayout();
            this.pnlBuilt.SuspendLayout();
            this.pnlDifference.SuspendLayout();
            this.SuspendLayout();
            // 
            // tmrClock
            // 
            this.tmrClock.Interval = 1000;
            this.tmrClock.Tick += new System.EventHandler(this.tmrClock_Tick);
            // 
            // tmrNetStatus
            // 
            this.tmrNetStatus.Interval = 1000;
            this.tmrNetStatus.Tick += new System.EventHandler(this.tmrNetStatus_Tick);
            // 
            // lblCurrentDateTime
            // 
            this.lblCurrentDateTime.AutoSize = true;
            this.lblCurrentDateTime.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentDateTime.Location = new System.Drawing.Point(12, 22);
            this.lblCurrentDateTime.Name = "lblCurrentDateTime";
            this.lblCurrentDateTime.Size = new System.Drawing.Size(127, 59);
            this.lblCurrentDateTime.TabIndex = 0;
            this.lblCurrentDateTime.Text = "TIME";
            // 
            // tmrNUMATO
            // 
            this.tmrNUMATO.Interval = 125;
            this.tmrNUMATO.Tick += new System.EventHandler(this.tmrNUMATO_Tick);
            // 
            // DGVProduction
            // 
            this.DGVProduction.AllowUserToAddRows = false;
            this.DGVProduction.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.DGVProduction.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DGVProduction.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DGVProduction.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGVProduction.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVProduction.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DGVProduction.ColumnHeadersHeight = 72;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGVProduction.DefaultCellStyle = dataGridViewCellStyle3;
            this.DGVProduction.Location = new System.Drawing.Point(12, 104);
            this.DGVProduction.Name = "DGVProduction";
            this.DGVProduction.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVProduction.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DGVProduction.RowHeadersVisible = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Calibri", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Black;
            this.DGVProduction.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.DGVProduction.Size = new System.Drawing.Size(1326, 519);
            this.DGVProduction.TabIndex = 1;
            this.DGVProduction.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.DGVProduction_DataBindingComplete);
            // 
            // pnlTime
            // 
            this.pnlTime.BackColor = System.Drawing.Color.Black;
            this.pnlTime.Controls.Add(this.lblCurrentDateTime);
            this.pnlTime.Location = new System.Drawing.Point(0, -2);
            this.pnlTime.Name = "pnlTime";
            this.pnlTime.Size = new System.Drawing.Size(788, 100);
            this.pnlTime.TabIndex = 2;
            // 
            // pnlGoal
            // 
            this.pnlGoal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlGoal.BackColor = System.Drawing.Color.Black;
            this.pnlGoal.Controls.Add(this.lblGoalLabel);
            this.pnlGoal.Controls.Add(this.lblGoal);
            this.pnlGoal.Location = new System.Drawing.Point(904, -2);
            this.pnlGoal.Name = "pnlGoal";
            this.pnlGoal.Size = new System.Drawing.Size(448, 100);
            this.pnlGoal.TabIndex = 3;
            // 
            // lblGoalLabel
            // 
            this.lblGoalLabel.AutoSize = true;
            this.lblGoalLabel.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGoalLabel.Location = new System.Drawing.Point(44, 22);
            this.lblGoalLabel.Name = "lblGoalLabel";
            this.lblGoalLabel.Size = new System.Drawing.Size(160, 59);
            this.lblGoalLabel.TabIndex = 1;
            this.lblGoalLabel.Text = "GOAL: ";
            // 
            // lblGoal
            // 
            this.lblGoal.AutoSize = true;
            this.lblGoal.Font = new System.Drawing.Font("Calibri", 62.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGoal.Location = new System.Drawing.Point(199, 0);
            this.lblGoal.Name = "lblGoal";
            this.lblGoal.Size = new System.Drawing.Size(211, 101);
            this.lblGoal.TabIndex = 0;
            this.lblGoal.Text = "0000";
            // 
            // pnlBuilt
            // 
            this.pnlBuilt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pnlBuilt.BackColor = System.Drawing.Color.Black;
            this.pnlBuilt.Controls.Add(this.lblBuiltLabel);
            this.pnlBuilt.Controls.Add(this.lblBuilt);
            this.pnlBuilt.Location = new System.Drawing.Point(0, 629);
            this.pnlBuilt.Name = "pnlBuilt";
            this.pnlBuilt.Size = new System.Drawing.Size(448, 100);
            this.pnlBuilt.TabIndex = 4;
            // 
            // lblBuiltLabel
            // 
            this.lblBuiltLabel.AutoSize = true;
            this.lblBuiltLabel.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBuiltLabel.Location = new System.Drawing.Point(44, 22);
            this.lblBuiltLabel.Name = "lblBuiltLabel";
            this.lblBuiltLabel.Size = new System.Drawing.Size(158, 59);
            this.lblBuiltLabel.TabIndex = 1;
            this.lblBuiltLabel.Text = "BUILT: ";
            // 
            // lblBuilt
            // 
            this.lblBuilt.AutoSize = true;
            this.lblBuilt.Font = new System.Drawing.Font("Calibri", 62.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBuilt.Location = new System.Drawing.Point(199, 0);
            this.lblBuilt.Name = "lblBuilt";
            this.lblBuilt.Size = new System.Drawing.Size(211, 101);
            this.lblBuilt.TabIndex = 0;
            this.lblBuilt.Text = "0000";
            // 
            // pnlDifference
            // 
            this.pnlDifference.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlDifference.BackColor = System.Drawing.Color.Black;
            this.pnlDifference.Controls.Add(this.lblDifferenceLabel);
            this.pnlDifference.Controls.Add(this.lblDifference);
            this.pnlDifference.Location = new System.Drawing.Point(759, 629);
            this.pnlDifference.Name = "pnlDifference";
            this.pnlDifference.Size = new System.Drawing.Size(593, 100);
            this.pnlDifference.TabIndex = 5;
            // 
            // lblDifferenceLabel
            // 
            this.lblDifferenceLabel.AutoSize = true;
            this.lblDifferenceLabel.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDifferenceLabel.Location = new System.Drawing.Point(35, 22);
            this.lblDifferenceLabel.Name = "lblDifferenceLabel";
            this.lblDifferenceLabel.Size = new System.Drawing.Size(322, 59);
            this.lblDifferenceLabel.TabIndex = 1;
            this.lblDifferenceLabel.Text = "OVER/UNDER: ";
            // 
            // lblDifference
            // 
            this.lblDifference.AutoSize = true;
            this.lblDifference.Font = new System.Drawing.Font("Calibri", 62.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDifference.Location = new System.Drawing.Point(344, 0);
            this.lblDifference.Name = "lblDifference";
            this.lblDifference.Size = new System.Drawing.Size(211, 101);
            this.lblDifference.TabIndex = 0;
            this.lblDifference.Text = "0000";
            // 
            // tmrWindowFile
            // 
            this.tmrWindowFile.Interval = 300000;
            this.tmrWindowFile.Tick += new System.EventHandler(this.tmrWinFile_Tick);
            // 
            // tmrCountFile
            // 
            this.tmrCountFile.Interval = 60000;
            this.tmrCountFile.Tick += new System.EventHandler(this.tmrGlassFile_Tick);
            // 
            // lblSelectedLine
            // 
            this.lblSelectedLine.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblSelectedLine.AutoSize = true;
            this.lblSelectedLine.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectedLine.Location = new System.Drawing.Point(759, 20);
            this.lblSelectedLine.Name = "lblSelectedLine";
            this.lblSelectedLine.Size = new System.Drawing.Size(113, 59);
            this.lblSelectedLine.TabIndex = 1;
            this.lblSelectedLine.Text = "LINE";
            // 
            // tmrReadFiles
            // 
            this.tmrReadFiles.Interval = 600000;
            this.tmrReadFiles.Tick += new System.EventHandler(this.tmrReadFiles_Tick);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.lblSelectedLine);
            this.Controls.Add(this.pnlDifference);
            this.Controls.Add(this.pnlBuilt);
            this.Controls.Add(this.pnlGoal);
            this.Controls.Add(this.pnlTime);
            this.Controls.Add(this.DGVProduction);
            this.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "frmMain";
            this.Text = "TSHOWN Leaderboard";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGVProduction)).EndInit();
            this.pnlTime.ResumeLayout(false);
            this.pnlTime.PerformLayout();
            this.pnlGoal.ResumeLayout(false);
            this.pnlGoal.PerformLayout();
            this.pnlBuilt.ResumeLayout(false);
            this.pnlBuilt.PerformLayout();
            this.pnlDifference.ResumeLayout(false);
            this.pnlDifference.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Timer tmrClock;
        public System.Windows.Forms.Timer tmrNetStatus;
        private System.Windows.Forms.Label lblCurrentDateTime;
        public System.Windows.Forms.Timer tmrNUMATO;
        private System.Windows.Forms.DataGridView DGVProduction;
        private System.Windows.Forms.Panel pnlTime;
        private System.Windows.Forms.Panel pnlGoal;
        private System.Windows.Forms.Label lblGoalLabel;
        private System.Windows.Forms.Label lblGoal;
        private System.Windows.Forms.Panel pnlBuilt;
        private System.Windows.Forms.Label lblBuiltLabel;
        private System.Windows.Forms.Label lblBuilt;
        private System.Windows.Forms.Panel pnlDifference;
        private System.Windows.Forms.Label lblDifferenceLabel;
        private System.Windows.Forms.Label lblDifference;
        public System.Windows.Forms.Timer tmrWindowFile;
        public System.Windows.Forms.Timer tmrCountFile;
        private System.Windows.Forms.Label lblSelectedLine;
        public System.Windows.Forms.Timer tmrReadFiles;
    }
}

