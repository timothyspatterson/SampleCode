﻿using CoreScanner;
using log4net;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace TSHOWNLeaderboard
{
    public partial class frmMain : Form
    {
        CCoreScanner cCoreScanner = new CCoreScanner();
        public static ILog log = LogManager.GetLogger("log");
        public bool CoreScannerDriverStatus { get; set; }
        public int status;
        public string inXML;
        public string outXML;
        public int opCode;
        public static ProductionValidationEntities DB = new ProductionValidationEntities();
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            DateTime dtLastCount;
            DateTime dtFirstCount;
            //Check Directories and Output Files
            #region Check Directories and Output File Status
            bool exists = System.IO.Directory.Exists(@"C:\ProductionFiles\");
            if (!exists)
                System.IO.Directory.CreateDirectory(@"C:\ProductionFiles\");


            global.sCountOutputFile = @"C:\ProductionFiles\CountOutput.txt";
            global.sWindowOutputFile = @"C:\ProductionFiles\WindowsOutput.txt";
            #endregion

            //Populate Offline Lists
            #region Populate Offline Lists
            global.PopulateLineNames();
            global.PopulateOfflineLineRate();

            #endregion
            //Get Line Selection
            #region Prompt User for Line Selection
            ///INSERT LINE SELECTION FORM POPUP HERE
            frmLineSelect frmLineSelect = new frmLineSelect();
            frmLineSelect.ShowDialog();
            lblSelectedLine.Text = global.sFullSelectedLineName;

            #endregion

            //Initiate Data Reads
            #region Initiate Data Reading Based On Production Type
            try
            {
                if (global.sLineType == "WINDOW")
                {

                    VirtualCOM.GetAllVirtualPorts();
                    VirtualCOM.listenToSSP();
                    BarcodeLIB.CoreScanner.initiateCoreScanners();
                    processNFRC.createNFRCList();
                }
                else
                {
                    NUMATO.GetAllVirtualPorts();
                }
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine frmMAIN_Load with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine frmMAIN_Load with the following error " + EX);
            }
            #endregion
            //MessageBox.Show("STOP 3");
            //Get the Current Hour ID
            global.getCurrentHourID();

            //Get Initial Network Status
            netstatus.GetNetStatus();
            //MessageBox.Show("STOP 4");
            //Initiate Timers For Production Types
            #region Initiate Timers
            if (global.sLineType == "GLASS")
            {
                tmrNUMATO.Enabled = true;
            }
            tmrClock.Enabled = true;
            tmrNetStatus.Enabled = true;
            tmrReadFiles.Enabled = true;
            #endregion
            //MessageBox.Show("STOP 5");
            //Get Counts Online/Offline
            #region GetTodaysCounts

            try
            {
                if (global.sLineType == "WINDOW")
                {
                    if (global.bNetworkConnected == false)
                    {
                        //FROM FILE
                        //IF THE WINDOW OUTPUT FILE EXISTS
                        if (File.Exists(global.sWindowOutputFile))
                        {
                            var readlogFile = File.ReadAllLines(global.sWindowOutputFile).ToList();
                            //IF THE WINDOWS OUTPUT FILE IS NOT EMPTY
                            if (readlogFile.Count > 0)
                            {
                                foreach (var item in readlogFile)
                                {
                                    //GET THE DATE ONLY FROM THE FIRST RECORD IN THE FILE FROM THE DELIMITED STRING
                                    dtLastCount = Convert.ToDateTime(Regex.Split(item, "||")[2]).Date;
                                    //IF THE DELIMITED DATE IS EQUAL TO TODAY THEN COUNT THE RECORDS
                                    if (dtLastCount == DateTime.Today)
                                    {
                                        global.iUnitsThisShift = global.iUnitsThisShift + 1;
                                    }
                                }
                            }
                        }
                        else
                        {
                            global.iUnitsThisShift = 0;
                        }
                    }
                    else
                    {
                        //GET WINDOW TOTALS FROM DATABASE
                        dtLastCount = DateTime.Today;
                        if(global.iCurrentHourRangeID < 12)
                        {
                            dtLastCount = dtLastCount.AddHours(-7);
                            global.iUnitsThisShift = Convert.ToInt32(DB.tblWindowProduction.Where(w => w.LineID == global.sSelectedLineName && w.ProductionDTS >= dtLastCount).Sum(s => s.QTY));
                        }
                        else
                        {
                            global.iUnitsThisShift = Convert.ToInt32(DB.tblWindowProduction.Where(w => w.LineID == global.sSelectedLineName && w.ProductionDTS >= dtLastCount).Sum(s => s.QTY));
                        }
                    }
                }
                else
                {
                    //GET GLASS TOTALS
                    if (global.bNetworkConnected == false)
                    {
                        //FROM FILE
                        if (File.Exists(global.sCountOutputFile))
                        {
                            var readlogFile = File.ReadAllLines(global.sCountOutputFile).ToList();
                            //IF THE WINDOWS OUTPUT FILE IS NOT EMPTY
                            if (readlogFile.Count > 0)
                            {
                                foreach (var item in readlogFile)
                                {
                                    //GET THE DATE ONLY FROM THE FIRST RECORD IN THE FILE FROM THE DELIMITED STRING
                                    dtLastCount = Convert.ToDateTime(Regex.Split(item, "||")[3]).Date;
                                    //IF THE DELIMITED DATE IS EQUAL TO TODAY THEN COUNT THE RECORDS
                                    if (dtLastCount == DateTime.Today)
                                    {
                                        global.iUnitsThisShift = global.iUnitsThisShift + Convert.ToInt32(Regex.Split(item, "||")[2]);
                                    }
                                }
                            }
                        }
                        else
                        {
                            global.iUnitsThisShift = 0;
                        }
                    }
                    else
                    {
                        //GET GLASS TOTALS FROM DATABASE
                        dtLastCount = DateTime.Today;
                        dtFirstCount = DateTime.Today;
                        if (global.iCurrentHourRangeID < 12)
                        {
                            dtLastCount = dtLastCount.AddHours(17);
                            dtFirstCount = dtFirstCount.AddHours(5);
                            global.iUnitsThisShift = Convert.ToInt32(DB.tblGlassProduction.Where(w => w.LineID == global.sSelectedLineName && w.ProductionDTS >= dtFirstCount  && w.ProductionDTS <= dtLastCount).Sum(s => s.QTY));
                        }
                        else
                        {
                            dtLastCount = dtLastCount.AddDays(1);
                            dtLastCount = dtLastCount.AddHours(4);
                            dtFirstCount = dtFirstCount.AddHours(18);
                            global.iUnitsThisShift = Convert.ToInt32(DB.tblGlassProduction.Where(w => w.LineID == global.sSelectedLineName && w.ProductionDTS >= dtFirstCount && w.ProductionDTS <= dtLastCount).Sum(s => s.QTY));
                        }
                    }
                }
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine frmMAIN_Load at GetTodaysCounts with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine frmMAIN_Load with the following error " + EX);
            }

            #endregion
            //MessageBox.Show("STOP 6");
            //Get Line Rates and Populate Main Grid
            try
            {
                global.getLineRate(global.sSelectedLineName);
                global.populateCurrentGridData();
                //throw new Exception("FAIL");
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine frmMAIN_Load with the following error " + EX);
                // MessageBox.Show("I have failed in subroutine frmMAIN_Load with the following error " + EX);
            }
            //MessageBox.Show("STOP 7");
            //Maximize the window size
            this.WindowState = FormWindowState.Maximized;
        }

        //CLOCK ENGINE
        private void tmrClock_Tick(object sender, EventArgs e)
        {
            global.getCurrentHourID();
            if (DateTime.Now.Minute == 00 && DateTime.Now.Second >= 00 && DateTime.Now.Second <= 03)
            {
                global.iCurrentHourRangeCount = 0;
            }

            if (DateTime.Now.Hour == 4 && DateTime.Now.Minute == 00 && DateTime.Now.Second >= 00 && DateTime.Now.Second <= 03)
            {
                global.iCurrentHourRangeCount = 0;
                global.iUnitsThisShift = 0;
                lblGoal.Text = "0";
                lblBuilt.Text = "0";
            }

            lblCurrentDateTime.Text = DateTime.Now.ToString("dddd, dd MMMM h:mm:ss tt");
        }

        //NETWORK STATUS ENGINE
        private void tmrNetStatus_Tick(object sender, EventArgs e)
        {
            netstatus.GetNetStatus();
        }

        //COUNTER ENGINE
        private void tmrNUMATO_Tick(object sender, EventArgs e)
        {
            NUMATO.ReadGPIOADC(NUMATO.IGPIOCOMPort);
        }

        private void tmrWinFile_Tick(object sender, EventArgs e)
        {
            //if(global.bNetworkConnected == false)
            //{
            //    global.WriteWindowOutputFile();
            //}
        }

        private void tmrGlassFile_Tick(object sender, EventArgs e)
        {
            if (global.bNetworkConnected == false)
            {
                global.WriteCountToOutputFile();
            }
        }



        public void UdateDGV(List<GridData> lGridData)
        {
            frmMain main = Application.OpenForms["frmMain"] as frmMain;
            main.UpdateDataGridView(lGridData);
        }
        public void UpdateDataGridView(List<GridData> lGridData)
        {
            int iGridWidth = DGVProduction.Width;
            int iGridHeight = DGVProduction.Height;
            DateTime dtTodayTwelveAM = DateTime.Now.Date;
            DateTime dTodayShiftStart = DateTime.Now;
            DateTime dTodayShiftEnd = DateTime.Now;

            if (DateTime.Now.Hour >= 5 && DateTime.Now.Hour <= 16)
            {
                dTodayShiftStart = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 6, 0, 0);
                dTodayShiftEnd = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 0, 0);
            }

            if (DateTime.Now.Hour > 16)
            {
                dTodayShiftStart = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 0, 0);
                dTodayShiftEnd = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 24, 59, 59);
                
            }
            
            if(DateTime.Now.Hour < 5)
            {
                dTodayShiftStart = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 16, 0, 0);
                dTodayShiftStart = dTodayShiftStart.AddDays(-1);
                dTodayShiftEnd = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 5, 0, 0);
            }


            //GET PRODUCTION TOTALS

            //CHANGE TO FIRST AND SECOND SHIFT RANGES
            if (DateTime.Now.Hour > 4 && DateTime.Now.Hour < 17)
            {
                global.iUnitGoalForLine = global.lLineRates.Where(w => w.TimeRangeID >= 1 && w.TimeRangeID <= 11).Select(s => s.LineHourlyGoal).Sum();
            }
            else
            {
                global.iUnitGoalForLine = global.lLineRates.Where(w => w.TimeRangeID > 11).Select(s => s.LineHourlyGoal).Sum();
            }
                
            if (global.sLineType == "GLASS")
            {
                if(global.bNetworkConnected == false)
                {
                    //string[] LineDetails;
                    var readlogFile = File.ReadAllLines(global.sWindowOutputFile).ToList();
                    //foreach(var item in readlogFile)
                    //{
                    //    LineDetails = Regex.Split(item, "||");

                    //}
                    global.iUnitsThisShift = readlogFile.Count;
                }
                else
                {
                    //global.iUnitsThisShift = Convert.ToInt32(DB.tblGlassProduction.Where(w => w.LineID == global.sSelectedLineName && w.ProductionDTS >= dtTodayTwelveAM && w.ProductionDTS <= DateTime.Now).Select(s => s.QTY).Sum());
                    global.iUnitsThisShift = Convert.ToInt32(DB.tblGlassProduction.Where(w => w.LineID == global.sSelectedLineName && w.ProductionDTS >= dTodayShiftStart && w.ProductionDTS <= DateTime.Now).Select(s => s.QTY).Sum());
                }
            }
            else
            {
                if (global.bNetworkConnected == false)
                {
                    var readlogFile = File.ReadAllLines(global.sWindowOutputFile).ToList();
                    global.iUnitsThisShift = readlogFile.Count;
                }
                else
                {
                    global.iUnitsThisShift = Convert.ToInt32(DB.tblWindowProduction.Where(w => w.LineID == global.sSelectedLineName && w.ProductionDTS >= dTodayShiftStart && w.ProductionDTS <= DateTime.Now).Select(s => s.QTY).Sum());
                }
                    
            }
            global.iUnitsOverUnder = global.iUnitsThisShift - global.iUnitGoalForLine;

            //UPDATE DGV
            Invoke(new Action(() => DGVProduction.DataSource = lGridData));
            Invoke(new Action(() => lblGoal.Text = global.iUnitGoalForLine.ToString()));
            Invoke(new Action(() => lblBuilt.Text = global.iUnitsThisShift.ToString()));
            Invoke(new Action(() => lblDifference.Text = global.iUnitsOverUnder.ToString()));

            Invoke(new Action(() => DGVProduction.Columns[0].Width = (50 * iGridWidth) / 100));
            Invoke(new Action(() => DGVProduction.Columns[0].HeaderText = "HOUR RANGE"));
            Invoke(new Action(() => DGVProduction.Columns[1].HeaderText = "HOUR GOAL"));
            Invoke(new Action(() => DGVProduction.Columns[2].HeaderText = "UNITS COMPLETED"));
            Invoke(new Action(() => DGVProduction.Columns[3].HeaderText = "OVER/UNDER GOAL"));

            for(int i = 0; i < 3;i++)
            {
                int icompleted = Convert.ToInt32(DGVProduction.Rows[i].Cells[3].Value);
                if (icompleted < 0)
                {
                    Invoke(new Action(() => DGVProduction.Rows[i].Cells[3].Style.BackColor = Color.DarkOrange));
                }
                else
                {
                    Invoke(new Action(() => DGVProduction.Rows[i].Cells[3].Style.BackColor = Color.DarkGreen));
                }
            }
        }

        private void DGVProduction_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            int iCurrentHour = 0;
            int iGridHour = 0;
            int i = 0;
            string sHourRange = "";

            iCurrentHour = DateTime.Now.Hour;
            for(i = 0; i< global.lGridData.Count;i++)
            {
                sHourRange = global.lGridData[i].sHourRange.ToString().Substring(0, 1);
                iGridHour = Convert.ToInt32(sHourRange);
                //if(iCurrentHour == iGridHour && (i+1) < 3)
                if (iCurrentHour == iGridHour)
                {
                    DGVProduction.Rows[i].DefaultCellStyle.BackColor = Color.DarkGreen;
                    break;
                }
                else
                {
                    DGVProduction.Rows[2].DefaultCellStyle.BackColor = Color.DarkGreen;
                }
            }
            
            DGVProduction.RowTemplate.MinimumHeight = 140;
            DGVProduction.ClearSelection();
        }

        private void tmrReadFiles_Tick(object sender, EventArgs e)
        {
            if(global.bNetworkConnected == true)
            {
                bool Countexists = System.IO.File.Exists(global.sCountOutputFile);
                bool Windowsexists = System.IO.File.Exists(global.sWindowOutputFile);

                if(Countexists == true)
                {
                    var readOutputFile = File.ReadAllLines(global.sCountOutputFile).ToList();
                    if(readOutputFile.Count > 0)
                    {
                        global.UpdateDBFromOutputFiles();
                        File.Delete(global.sCountOutputFile);
                    }
                }

                if(Windowsexists == true)
                {
                    var readOutputFile = File.ReadAllLines(global.sWindowOutputFile).ToList();
                    if (readOutputFile.Count > 0)
                    {
                        global.UpdateDBFromOutputFiles();
                        File.Delete(global.sWindowOutputFile);
                    }
                }
            }
        }
    }
}
