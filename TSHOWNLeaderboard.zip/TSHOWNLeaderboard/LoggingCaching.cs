﻿using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TSHOWNLeaderboard
{
    class LoggingCaching
    {
        public static ILog log = LogManager.GetLogger("log");
        public static string CacheFilePath { get; set; }
        public static string LogFilePath { get; set; }
        public static string logFile { get; set; }
        public static bool bLogFileExits { get; set; }

        //Create a cache file
        //Logging - Enabled
        public static void CreateCacheFile()
        {
            bool exists = false;

            CacheFilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CacheFile_" + DateTime.Today + ".txt");
            exists = File.Exists(CacheFilePath);
            try
            {
                if (exists != true)
                {
                    File.Create(CacheFilePath);
                }
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine CreateCacheFile with the following error " + EX);
                MessageBox.Show("I have failed in subroutine CreateCacheFile with the following error " + EX);
            }
        }

        //Create a log file
        //Logging - Enabled
        public void CreateLogFile()
        {
            string checkLogFilePath = "";
            bool exists = false;
            string fileName = "";

            checkLogFilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "LineProductionLogFile.txt");
            exists = File.Exists(checkLogFilePath);
            try
            {
                if (exists != true)
                {
                    fileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "LineProductionLogFile.txt");

                    File.Create(fileName);
                    bLogFileExits = true;
                }
                logFile = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "LineProductionLogFile.txt");
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine CreateLogFile with the following error " + EX);
                MessageBox.Show("I have failed in subroutine CreateLogFile with the following error " + EX);
            }
        }
    }
}
