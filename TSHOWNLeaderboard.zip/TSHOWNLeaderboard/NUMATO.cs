﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace TSHOWNLeaderboard
{
    class NUMATO
    {
        public static List<string> COMPorts { get; set; }
        public static System.IO.Ports.SerialPort CPort { get; set; }
        public static int IGPIOCOMPort { get; set; }
        public static string SGPIOCOMPort { get; set; }
        public static bool bSensor4ON { get; set; }
        public static int ADC04Reading { get; set; }
        public static int ISensor4Count { get; set; }

        public static void GetAllVirtualPorts()
        {
            List<string> tempList = new List<string>();

            try
            {
                ManagementObjectSearcher searcher = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_PnPEntity");
                foreach (ManagementObject queryObj in searcher.Get())
                {
                    ManagementClass processClass = new ManagementClass("Win32_PnPEntity");
                    ManagementObjectCollection Ports = processClass.GetInstances();
                    foreach (ManagementObject property in Ports)
                    {
                        if (property.GetPropertyValue("Name") != null)
                        {
                            if (property.GetPropertyValue("Name").ToString().Contains("Numato") &&
                                property.GetPropertyValue("Name").ToString().Contains("COM"))
                            {
                                //MessageBox.Show(property.GetPropertyValue("Name").ToString());
                                string comPort = property.GetPropertyValue("Name").ToString().Split('(')[1].Replace(")", "");
                                CPort = new System.IO.Ports.SerialPort(comPort);
                                SGPIOCOMPort = comPort;
                                IGPIOCOMPort = Convert.ToInt32(comPort.Replace("COM", ""));
                                return;
                            }
                        }
                    }
                }
            }
            catch (ManagementException EX)
            {
                //log.Error(EX);
            }
        }

        public static void ReadGPIOADC(int COMPort)
        {
            //MAIN main = new MAIN();
            int iReadNumber = 0;
            if (!CPort.IsOpen)
            {
                CPort.Open();
            }

            if (IGPIOCOMPort != 0)
            {
                if (global.iCurrentHourRangeCount % 5 == 0)
                {
                    CPort.DiscardInBuffer();
                }
                CPort.Write("gpio read " + 4 + "\r");
                System.Threading.Thread.Sleep(10);
                string response = CPort.ReadExisting();
                if (response != "")
                {
                    response = response.Remove(0, 11);
                    response = response.TrimEnd(response[response.Length - 1]);
                    Regex.Replace(response, "[^0-9.]", "");

                    try
                    {
                        if (response != null)
                        {
                            iReadNumber = Convert.ToInt32(response);
                            ADC04Reading = iReadNumber;
                            if (iReadNumber == 1)
                            {
                                bSensor4ON = false;
                            }
                            else
                            {
                                if (ADC04Reading == 0)
                                {
                                    if (bSensor4ON == false)
                                    {
                                        ISensor4Count = ISensor4Count + 1;
                                        global.iCurrentHourRangeCount = global.iCurrentHourRangeCount + 1;
                                        global.iUnitsThisShift = global.iUnitsThisShift + 1;
                                        if(global.bNetworkConnected == true)
                                        {
                                            global.UpdateProductionCountDB();
                                        }
                                        else
                                        {
                                            global.WriteCountToOutputFile();
                                        }
                                        
                                        global.populateCurrentGridData();

                                        bSensor4ON = true;
                                    }
                                }
                            }
                        }
                        else
                        {
                            return;
                        }
                    }
                    catch (Exception EX)
                    {
                        //log.Error(EX);
                        return;
                    }
                }
            }
        }
    }
}
