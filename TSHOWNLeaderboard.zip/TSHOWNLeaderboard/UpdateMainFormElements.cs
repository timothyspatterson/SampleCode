﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSHOWNLeaderboard
{
    class UpdateMainFormElements
    {
        private frmMain _form = null;
        public UpdateMainFormElements(frmMain form)
        {
            _form = form;
        }

        public void UpdateDGV()
        {
            _form.UdateDGV(global.lGridData);
        }


        //public void UpdateCurrentPT()
        //{
        //    _form.SetCurrentPT(Global.sCurrentPT);
        //}

        //public void UpdateCurrentID()
        //{
        //    _form.SetCurrentID(Global.iBarID);
        //}

        //public void UpdateDGVSource()
        //{
        //    _form.SetDGVDataSource();
        //}
    }
}
