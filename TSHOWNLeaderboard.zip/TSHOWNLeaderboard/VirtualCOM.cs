﻿using log4net;
using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;

namespace TSHOWNLeaderboard
{
    class VirtualCOM
    {
        public static ILog log = LogManager.GetLogger("log");
        public static List<string> COMPorts { get; set; }
        public static System.IO.Ports.SerialPort CPort { get; set; }
        public static string ScannedValue { get; set; }

        public static void GetAllVirtualPorts()
        {
            List<string> tempList = new List<string>();

            using (var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Caption like '%(COM%'"))
            {
                var portnames = SerialPort.GetPortNames();
                var ports = searcher.Get().Cast<ManagementBaseObject>().ToList().Select(p => p["Caption"].ToString());

                tempList = portnames.Select(n => n + " - " + ports.FirstOrDefault(s => s.Contains(n))).ToList();
            }
            var t = tempList.Where(w => tempList.Any(folder => w.Contains("Zebra") || w.Contains("Virtual")));
            COMPorts = t.ToList();
        }

        public static void listenToSSP()
        {
            try
            {
                GetAllVirtualPorts();
                CPort = new System.IO.Ports.SerialPort(COMPorts[0].Split('-')[0].Trim());

                if (CPort.IsOpen == false)
                {
                    CPort.Open();
                    CPort.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(COMGetData);
                }
                else
                {
                    CPort.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(COMGetData);
                }
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine listenToSSP with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine ##listenToSSP## with the following error " + EX);
            }
        }

        public static void COMGetData(object sender, SerialDataReceivedEventArgs e)
        {
            string InputData = "";
            InputData = CPort.ReadExisting();
            if (InputData != String.Empty)
            {
                try
                {
                    ScannedValue = InputData;
                    //Global.scannedValue = ScannedValue;
                }
                catch (Exception EX)
                {
                    log.Debug("I have failed in subroutine COMGetData with the following error " + EX);
                    //MessageBox.Show("I have failed in subroutine COMGetData with the following error " + EX);
                }
            }
        }
    }
}
