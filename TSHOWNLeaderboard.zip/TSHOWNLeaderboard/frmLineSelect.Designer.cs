﻿namespace TSHOWNLeaderboard
{
    partial class frmLineSelect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxLineNames = new System.Windows.Forms.ComboBox();
            this.lblSelectLineENG = new System.Windows.Forms.Label();
            this.lblSelectLineSPN = new System.Windows.Forms.Label();
            this.btnSelectLine = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cbxLineNames
            // 
            this.cbxLineNames.FormattingEnabled = true;
            this.cbxLineNames.Location = new System.Drawing.Point(16, 79);
            this.cbxLineNames.Name = "cbxLineNames";
            this.cbxLineNames.Size = new System.Drawing.Size(476, 34);
            this.cbxLineNames.TabIndex = 0;
            // 
            // lblSelectLineENG
            // 
            this.lblSelectLineENG.AutoSize = true;
            this.lblSelectLineENG.Location = new System.Drawing.Point(128, 9);
            this.lblSelectLineENG.Name = "lblSelectLineENG";
            this.lblSelectLineENG.Size = new System.Drawing.Size(253, 26);
            this.lblSelectLineENG.TabIndex = 1;
            this.lblSelectLineENG.Text = "Select a line, then click\"OK\"";
            // 
            // lblSelectLineSPN
            // 
            this.lblSelectLineSPN.AutoSize = true;
            this.lblSelectLineSPN.Location = new System.Drawing.Point(32, 35);
            this.lblSelectLineSPN.Name = "lblSelectLineSPN";
            this.lblSelectLineSPN.Size = new System.Drawing.Size(444, 26);
            this.lblSelectLineSPN.TabIndex = 2;
            this.lblSelectLineSPN.Text = "Seleccione una línea, luego haga clic en \"Aceptar\"";
            // 
            // btnSelectLine
            // 
            this.btnSelectLine.BackColor = System.Drawing.Color.DarkGreen;
            this.btnSelectLine.Location = new System.Drawing.Point(193, 135);
            this.btnSelectLine.Name = "btnSelectLine";
            this.btnSelectLine.Size = new System.Drawing.Size(123, 44);
            this.btnSelectLine.TabIndex = 3;
            this.btnSelectLine.Text = "OKAY";
            this.btnSelectLine.UseVisualStyleBackColor = false;
            this.btnSelectLine.Click += new System.EventHandler(this.btnSelectLine_Click);
            // 
            // frmLineSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 26F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(506, 191);
            this.Controls.Add(this.btnSelectLine);
            this.Controls.Add(this.lblSelectLineSPN);
            this.Controls.Add(this.lblSelectLineENG);
            this.Controls.Add(this.cbxLineNames);
            this.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "frmLineSelect";
            this.Text = "SELECT LINE";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbxLineNames;
        private System.Windows.Forms.Label lblSelectLineENG;
        private System.Windows.Forms.Label lblSelectLineSPN;
        private System.Windows.Forms.Button btnSelectLine;
    }
}