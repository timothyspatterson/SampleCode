﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TSHOWNLeaderboard
{
    public partial class frmLineSelect : Form
    {
        public frmLineSelect()
        {
            InitializeComponent();
            cbxLineNames.DataSource = global.LineNames;
            cbxLineNames.DisplayMember = "LineName";
            cbxLineNames.ValueMember = "LineValue";
        }

        private void btnSelectLine_Click(object sender, EventArgs e)
        {
            global.sSelectedLineName = cbxLineNames.SelectedValue.ToString();
            global.sFullSelectedLineName = cbxLineNames.Text.Split('-')[1];
            if (global.sSelectedLineName.Contains("A") || global.sSelectedLineName.Contains("V"))
            {
                global.sLineType = "WINDOW";
            }
            else
            {
                global.sLineType = "GLASS";
            }
            this.Close();
        }
    }
}
