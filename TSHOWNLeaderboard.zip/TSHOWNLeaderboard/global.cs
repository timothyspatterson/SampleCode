﻿using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TSHOWNLeaderboard
{
    class global
    {
        public static string sSelectedLineName { get; set; }
        public static string sFullSelectedLineName { get; set; }
        public static List<LineRate> lLineRates { get; set; }
        public static List<GridData> lGridData { get; set; }
        public static List<LineNames> LineNames { get; set; }
        public static List<string> lFileContents { get; set; }
        public static int iCurrentHourRangeCount { get; set; }
        public static int iCurrentHourRangeID { get; set; }
        public static int iUnitsThisShift { get; set; }
        public static int iUnitsOverUnder { get; set; }
        public static int iUnitGoalForLine { get; set; }
        public static int iUnitID { get; set; }
        public static int iNFRC { get; set; }
        public static string sWindowOutputFile { get; set; }
        public static string sCountOutputFile { get; set; }
        public static string sLineType { get; set; }
        public static bool bNetworkConnected { get; set; }
        public static bool bOfflineMode { get; set; }
        public static ILog log = LogManager.GetLogger("log");
        public static ProductionValidationEntities DB = new ProductionValidationEntities();

        static global()
        {
            lLineRates = new List<LineRate>();
            lGridData = new List<GridData>();
            lFileContents = new List<string>();
        }

        #region COMPLETE
        public static void getCurrentHourID()
        {
            try
            {
                int iHour = Convert.ToInt32(DateTime.Now.Hour);
                if (iHour <= 5)
                {
                    global.iCurrentHourRangeID = (iHour + 19);
                }
                else
                {
                    global.iCurrentHourRangeID = (iHour - 5);
                }
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine getCurrentHourID with the following error " + EX);
                MessageBox.Show("I have failed in subroutine getCurrentHourID with the following error " + EX);
            }
        }

        #region ProcessScannedData
        public static string _scannedValue;
        public static string scannedValue
        {
            get { return _scannedValue; }
            set
            {
                _scannedValue = value;
                if (_scannedValue != "")
                {
                    ProcessScanData(_scannedValue);
                }
            }
        }
        #endregion
        public static void ProcessScanData(string sScannedData)
        {
            string[] id = sScannedData.Split('.');
            iUnitID = Convert.ToInt32(id[0]);
            iNFRC = Convert.ToInt32(id[1].Substring(0, 5));
            if (id[1].Contains(','))
            {
                string[] winParams = id[0].Split(',');
            }

            try
            {
                processNFRC.CurrentNFRCid = iNFRC;
                if(global.bNetworkConnected == true)
                {
                    if (!DB.NFRC.Any(x => x.NFRCID == iNFRC))
                    {
                        iNFRC = 16001;
                    }
                }
                else
                {
                    if (!processNFRC.NFRCValues.Any(x => x.NFRCID == iNFRC))
                    {
                        iNFRC = 16001;
                    }
                }
                
                processNFRC.createNFRCLabel();

                if (global.bNetworkConnected == true)
                {
                    if (!DB.tblInsert.Any(x => x.BarID == iUnitID))
                    {
                        tblInsert insertUnit = new tblInsert();
                        insertUnit.BarID = iUnitID;
                        insertUnit.DateStamp = DateTime.Now;
                        insertUnit.LineNum = sSelectedLineName;
                        DB.tblInsert.Add(insertUnit);
                        DB.SaveChanges();
                    }

                    if (DB.barinv.Any(x => x.id == iUnitID))
                    {
                        barinv UpdateProductionStatus = DB.barinv.Single(x => x.id == iUnitID);
                        UpdateProductionStatus.status = "Produced TSHOWN";
                        //UpdateProductionStatus.loadscandate = DateTime.Now;
                        UpdateProductionStatus.NFRC = id[1].Substring(0, 5);
                        DB.SaveChanges();
                    }
                    UpdateProductionCountDB();
                }
                else
                {
                    WriteWindowOutputFile();
                }
                global.populateCurrentGridData();
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine ProcessScanData with the following error " + EX);
                MessageBox.Show("I have failed in subroutine ProcessScanData with the following error " + EX);
            }
        }
        public static void GetOverUnderForShift()
        {
            try
            {
                iUnitsOverUnder = iUnitsThisShift - iUnitGoalForLine;
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine GetOverUnderForShift with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine WriteBarIDToNetOutFile with the following error " + EX);
            }
        }
        public static int GetOverUnderForHourRange(int iHourGoal)
        {
            int iHourlyDifference = 0;
            try
            {
                iHourlyDifference = iCurrentHourRangeCount - iHourGoal;
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine GetOverUnderForHourRange with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine WriteBarIDToNetOutFile with the following error " + EX);
            }
            return iHourlyDifference;
        }
        public static void PopulateOfflineLineRate()
        {
 
            TimeSpan startTime = new TimeSpan(0, 0, 0, 0);
            TimeSpan endTime = new TimeSpan(0, 0, 0, 0);


            startTime = new TimeSpan(0, 6, 0, 0);
            endTime = new TimeSpan(0, 7, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 1, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 7, 0, 0);
            endTime = new TimeSpan(0, 8, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 2, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 8, 0, 0);
            endTime = new TimeSpan(0, 9, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 3, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 9, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 4, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 11, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 5, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 11, 0, 0);
            endTime = new TimeSpan(0, 12, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 6, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 12, 0, 0);
            endTime = new TimeSpan(0, 13, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 7, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 13, 0, 0);
            endTime = new TimeSpan(0, 14, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 8, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 14, 0, 0);
            endTime = new TimeSpan(0, 15, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 9, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 15, 0, 0);
            endTime = new TimeSpan(0, 16, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 10, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 16, 0, 0);
            endTime = new TimeSpan(0, 17, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 11, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 17, 0, 0);
            endTime = new TimeSpan(0, 18, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 12, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 18, 0, 0);
            endTime = new TimeSpan(0, 19, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 13, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 19, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 14, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 21, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 15, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 21, 0, 0);
            endTime = new TimeSpan(0, 22, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 16, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 22, 0, 0);
            endTime = new TimeSpan(0, 23, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 17, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 23, 0, 0);
            endTime = new TimeSpan(0, 0, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 18, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 0, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 19, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 20, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 3, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 21, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 3, 0, 0);
            endTime = new TimeSpan(0, 4, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 22, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 4, 0, 0);
            endTime = new TimeSpan(0, 5, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 23, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 5, 0, 0);
            endTime = new TimeSpan(0, 6, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V1", TimeRangeID = 24, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 6, 0, 0);
            endTime = new TimeSpan(0, 7, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 1, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 7, 0, 0);
            endTime = new TimeSpan(0, 8, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 2, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 8, 0, 0);
            endTime = new TimeSpan(0, 9, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 3, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 9, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 4, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 11, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 5, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 11, 0, 0);
            endTime = new TimeSpan(0, 12, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 6, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 12, 0, 0);
            endTime = new TimeSpan(0, 13, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 7, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 13, 0, 0);
            endTime = new TimeSpan(0, 14, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 8, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 14, 0, 0);
            endTime = new TimeSpan(0, 15, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 9, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 15, 0, 0);
            endTime = new TimeSpan(0, 16, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 10, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 16, 0, 0);
            endTime = new TimeSpan(0, 17, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 11, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 17, 0, 0);
            endTime = new TimeSpan(0, 18, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 12, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 18, 0, 0);
            endTime = new TimeSpan(0, 19, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 13, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 19, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 14, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 21, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 15, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 21, 0, 0);
            endTime = new TimeSpan(0, 22, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 16, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 22, 0, 0);
            endTime = new TimeSpan(0, 23, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 17, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 23, 0, 0);
            endTime = new TimeSpan(0, 0, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 18, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 0, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 19, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 20, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 3, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 21, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 3, 0, 0);
            endTime = new TimeSpan(0, 4, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 22, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 4, 0, 0);
            endTime = new TimeSpan(0, 5, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 23, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 5, 0, 0);
            endTime = new TimeSpan(0, 6, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V2", TimeRangeID = 24, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 76, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 6, 0, 0);
            endTime = new TimeSpan(0, 7, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 1, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 7, 0, 0);
            endTime = new TimeSpan(0, 8, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 2, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 8, 0, 0);
            endTime = new TimeSpan(0, 9, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 3, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 9, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 4, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 11, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 5, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 11, 0, 0);
            endTime = new TimeSpan(0, 12, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 6, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 12, 0, 0);
            endTime = new TimeSpan(0, 13, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 7, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 13, 0, 0);
            endTime = new TimeSpan(0, 14, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 8, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 14, 0, 0);
            endTime = new TimeSpan(0, 15, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 9, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 15, 0, 0);
            endTime = new TimeSpan(0, 16, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 10, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 16, 0, 0);
            endTime = new TimeSpan(0, 17, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 11, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 17, 0, 0);
            endTime = new TimeSpan(0, 18, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 12, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 18, 0, 0);
            endTime = new TimeSpan(0, 19, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 13, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 19, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 14, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 21, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 15, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 21, 0, 0);
            endTime = new TimeSpan(0, 22, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 16, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 22, 0, 0);
            endTime = new TimeSpan(0, 23, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 17, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 23, 0, 0);
            endTime = new TimeSpan(0, 0, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 18, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 0, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 19, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 20, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 3, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 21, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 3, 0, 0);
            endTime = new TimeSpan(0, 4, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 22, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 4, 0, 0);
            endTime = new TimeSpan(0, 5, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 23, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 5, 0, 0);
            endTime = new TimeSpan(0, 6, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V3", TimeRangeID = 24, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 72, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 6, 0, 0);
            endTime = new TimeSpan(0, 7, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 1, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 7, 0, 0);
            endTime = new TimeSpan(0, 8, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 2, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 8, 0, 0);
            endTime = new TimeSpan(0, 9, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 3, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 9, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 4, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 11, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 5, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 11, 0, 0);
            endTime = new TimeSpan(0, 12, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 6, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 12, 0, 0);
            endTime = new TimeSpan(0, 13, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 7, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 13, 0, 0);
            endTime = new TimeSpan(0, 14, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 8, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 14, 0, 0);
            endTime = new TimeSpan(0, 15, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 9, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 15, 0, 0);
            endTime = new TimeSpan(0, 16, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 10, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 16, 0, 0);
            endTime = new TimeSpan(0, 17, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 11, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 17, 0, 0);
            endTime = new TimeSpan(0, 18, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 12, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 18, 0, 0);
            endTime = new TimeSpan(0, 19, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 13, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 19, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 14, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 21, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 15, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 21, 0, 0);
            endTime = new TimeSpan(0, 22, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 16, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 22, 0, 0);
            endTime = new TimeSpan(0, 23, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 17, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 23, 0, 0);
            endTime = new TimeSpan(0, 0, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 18, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 0, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 19, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 20, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 3, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 21, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 3, 0, 0);
            endTime = new TimeSpan(0, 4, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 22, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 4, 0, 0);
            endTime = new TimeSpan(0, 5, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 23, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 5, 0, 0);
            endTime = new TimeSpan(0, 6, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V4", TimeRangeID = 24, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 65, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 6, 0, 0);
            endTime = new TimeSpan(0, 7, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 1, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 7, 0, 0);
            endTime = new TimeSpan(0, 8, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 2, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 8, 0, 0);
            endTime = new TimeSpan(0, 9, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 3, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 9, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 4, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 11, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 5, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 11, 0, 0);
            endTime = new TimeSpan(0, 12, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 6, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 12, 0, 0);
            endTime = new TimeSpan(0, 13, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 7, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 13, 0, 0);
            endTime = new TimeSpan(0, 14, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 8, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 14, 0, 0);
            endTime = new TimeSpan(0, 15, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 9, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 15, 0, 0);
            endTime = new TimeSpan(0, 16, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 10, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 16, 0, 0);
            endTime = new TimeSpan(0, 17, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 11, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 17, 0, 0);
            endTime = new TimeSpan(0, 18, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 12, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 18, 0, 0);
            endTime = new TimeSpan(0, 19, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 13, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 19, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 14, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 21, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 15, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 21, 0, 0);
            endTime = new TimeSpan(0, 22, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 16, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 22, 0, 0);
            endTime = new TimeSpan(0, 23, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 17, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 23, 0, 0);
            endTime = new TimeSpan(0, 0, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 18, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 0, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 19, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 20, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 3, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 21, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 3, 0, 0);
            endTime = new TimeSpan(0, 4, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 22, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 4, 0, 0);
            endTime = new TimeSpan(0, 5, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 23, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 5, 0, 0);
            endTime = new TimeSpan(0, 6, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "V5", TimeRangeID = 24, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 95, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 6, 0, 0);
            endTime = new TimeSpan(0, 7, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 1, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 7, 0, 0);
            endTime = new TimeSpan(0, 8, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 2, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 8, 0, 0);
            endTime = new TimeSpan(0, 9, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 3, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 9, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 4, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 11, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 5, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 11, 0, 0);
            endTime = new TimeSpan(0, 12, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 6, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 12, 0, 0);
            endTime = new TimeSpan(0, 13, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 7, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 13, 0, 0);
            endTime = new TimeSpan(0, 14, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 8, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 14, 0, 0);
            endTime = new TimeSpan(0, 15, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 9, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 15, 0, 0);
            endTime = new TimeSpan(0, 16, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 10, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 16, 0, 0);
            endTime = new TimeSpan(0, 17, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 11, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 17, 0, 0);
            endTime = new TimeSpan(0, 18, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 12, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 18, 0, 0);
            endTime = new TimeSpan(0, 19, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 13, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 19, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 14, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 21, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 15, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 21, 0, 0);
            endTime = new TimeSpan(0, 22, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 16, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 22, 0, 0);
            endTime = new TimeSpan(0, 23, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 17, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 23, 0, 0);
            endTime = new TimeSpan(0, 0, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 18, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 0, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 19, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 20, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 3, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 21, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 3, 0, 0);
            endTime = new TimeSpan(0, 4, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 22, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 4, 0, 0);
            endTime = new TimeSpan(0, 5, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 23, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 5, 0, 0);
            endTime = new TimeSpan(0, 6, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A1", TimeRangeID = 24, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 6, 0, 0);
            endTime = new TimeSpan(0, 7, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 1, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 7, 0, 0);
            endTime = new TimeSpan(0, 8, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 2, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 8, 0, 0);
            endTime = new TimeSpan(0, 9, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 3, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 9, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 4, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 11, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 5, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 11, 0, 0);
            endTime = new TimeSpan(0, 12, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 6, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 12, 0, 0);
            endTime = new TimeSpan(0, 13, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 7, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 13, 0, 0);
            endTime = new TimeSpan(0, 14, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 8, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 14, 0, 0);
            endTime = new TimeSpan(0, 15, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 9, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 15, 0, 0);
            endTime = new TimeSpan(0, 16, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 10, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 16, 0, 0);
            endTime = new TimeSpan(0, 17, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 11, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 17, 0, 0);
            endTime = new TimeSpan(0, 18, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 12, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 18, 0, 0);
            endTime = new TimeSpan(0, 19, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 13, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 19, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 14, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 21, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 15, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 21, 0, 0);
            endTime = new TimeSpan(0, 22, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 16, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 22, 0, 0);
            endTime = new TimeSpan(0, 23, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 17, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 23, 0, 0);
            endTime = new TimeSpan(0, 0, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 18, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 0, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 19, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 20, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 3, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 21, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 3, 0, 0);
            endTime = new TimeSpan(0, 4, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 22, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 4, 0, 0);
            endTime = new TimeSpan(0, 5, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 23, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 5, 0, 0);
            endTime = new TimeSpan(0, 6, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A2", TimeRangeID = 24, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 60, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 6, 0, 0);
            endTime = new TimeSpan(0, 7, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 1, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 7, 0, 0);
            endTime = new TimeSpan(0, 8, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 2, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 8, 0, 0);
            endTime = new TimeSpan(0, 9, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 3, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 9, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 4, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 11, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 5, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 11, 0, 0);
            endTime = new TimeSpan(0, 12, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 6, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 12, 0, 0);
            endTime = new TimeSpan(0, 13, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 7, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 13, 0, 0);
            endTime = new TimeSpan(0, 14, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 8, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 14, 0, 0);
            endTime = new TimeSpan(0, 15, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 9, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 15, 0, 0);
            endTime = new TimeSpan(0, 16, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 10, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 16, 0, 0);
            endTime = new TimeSpan(0, 17, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 11, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 17, 0, 0);
            endTime = new TimeSpan(0, 18, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 12, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 18, 0, 0);
            endTime = new TimeSpan(0, 19, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 13, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 19, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 14, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 21, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 15, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 21, 0, 0);
            endTime = new TimeSpan(0, 22, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 16, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 22, 0, 0);
            endTime = new TimeSpan(0, 23, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 17, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 23, 0, 0);
            endTime = new TimeSpan(0, 0, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 18, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 0, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 19, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 20, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 3, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 21, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 3, 0, 0);
            endTime = new TimeSpan(0, 4, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 22, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 4, 0, 0);
            endTime = new TimeSpan(0, 5, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 23, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 5, 0, 0);
            endTime = new TimeSpan(0, 6, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "A3", TimeRangeID = 24, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 90, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 6, 0, 0);
            endTime = new TimeSpan(0, 7, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 1, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 7, 0, 0);
            endTime = new TimeSpan(0, 8, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 2, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 8, 0, 0);
            endTime = new TimeSpan(0, 9, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 3, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 9, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 4, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 11, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 5, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 11, 0, 0);
            endTime = new TimeSpan(0, 12, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 6, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 12, 0, 0);
            endTime = new TimeSpan(0, 13, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 7, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 13, 0, 0);
            endTime = new TimeSpan(0, 14, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 8, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 14, 0, 0);
            endTime = new TimeSpan(0, 15, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 9, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 15, 0, 0);
            endTime = new TimeSpan(0, 16, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 10, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 16, 0, 0);
            endTime = new TimeSpan(0, 17, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 11, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 17, 0, 0);
            endTime = new TimeSpan(0, 18, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 12, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 18, 0, 0);
            endTime = new TimeSpan(0, 19, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 13, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 19, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 14, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 21, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 15, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 21, 0, 0);
            endTime = new TimeSpan(0, 22, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 16, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 22, 0, 0);
            endTime = new TimeSpan(0, 23, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 17, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 23, 0, 0);
            endTime = new TimeSpan(0, 0, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 18, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 0, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 19, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 20, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 3, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 21, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 3, 0, 0);
            endTime = new TimeSpan(0, 4, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 22, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 4, 0, 0);
            endTime = new TimeSpan(0, 5, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 23, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 5, 0, 0);
            endTime = new TimeSpan(0, 6, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G1", TimeRangeID = 24, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 150, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 6, 0, 0);
            endTime = new TimeSpan(0, 7, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 1, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 7, 0, 0);
            endTime = new TimeSpan(0, 8, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 2, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 8, 0, 0);
            endTime = new TimeSpan(0, 9, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 3, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 9, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 4, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 11, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 5, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 11, 0, 0);
            endTime = new TimeSpan(0, 12, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 6, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 12, 0, 0);
            endTime = new TimeSpan(0, 13, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 7, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 13, 0, 0);
            endTime = new TimeSpan(0, 14, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 8, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 14, 0, 0);
            endTime = new TimeSpan(0, 15, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 9, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 15, 0, 0);
            endTime = new TimeSpan(0, 16, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 10, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 16, 0, 0);
            endTime = new TimeSpan(0, 17, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 11, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 17, 0, 0);
            endTime = new TimeSpan(0, 18, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 12, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 18, 0, 0);
            endTime = new TimeSpan(0, 19, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 13, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 19, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 14, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 21, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 15, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 21, 0, 0);
            endTime = new TimeSpan(0, 22, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 16, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 22, 0, 0);
            endTime = new TimeSpan(0, 23, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 17, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 23, 0, 0);
            endTime = new TimeSpan(0, 0, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 18, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 0, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 19, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 20, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 3, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 21, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 3, 0, 0);
            endTime = new TimeSpan(0, 4, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 22, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 4, 0, 0);
            endTime = new TimeSpan(0, 5, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 23, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 5, 0, 0);
            endTime = new TimeSpan(0, 6, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G2", TimeRangeID = 24, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 6, 0, 0);
            endTime = new TimeSpan(0, 7, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 1, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 7, 0, 0);
            endTime = new TimeSpan(0, 8, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 2, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 8, 0, 0);
            endTime = new TimeSpan(0, 9, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 3, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 9, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 4, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 11, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 5, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 11, 0, 0);
            endTime = new TimeSpan(0, 12, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 6, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 12, 0, 0);
            endTime = new TimeSpan(0, 13, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 7, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 13, 0, 0);
            endTime = new TimeSpan(0, 14, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 8, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 0.75m });

            startTime = new TimeSpan(0, 14, 0, 0);
            endTime = new TimeSpan(0, 15, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 9, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 15, 0, 0);
            endTime = new TimeSpan(0, 16, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 10, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 0.5m });

            startTime = new TimeSpan(0, 16, 0, 0);
            endTime = new TimeSpan(0, 17, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 11, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 17, 0, 0);
            endTime = new TimeSpan(0, 18, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 12, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 18, 0, 0);
            endTime = new TimeSpan(0, 19, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 13, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 19, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 14, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 21, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 15, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 21, 0, 0);
            endTime = new TimeSpan(0, 22, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 16, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 22, 0, 0);
            endTime = new TimeSpan(0, 23, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 17, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 23, 0, 0);
            endTime = new TimeSpan(0, 0, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 18, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 0, 0, 0);
            endTime = new TimeSpan(0, 1, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 19, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 1, 0, 0);
            endTime = new TimeSpan(0, 2, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 20, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 2, 0, 0);
            endTime = new TimeSpan(0, 3, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 21, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 3, 0, 0);
            endTime = new TimeSpan(0, 4, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 22, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 4, 0, 0);
            endTime = new TimeSpan(0, 5, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 23, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });

            startTime = new TimeSpan(0, 5, 0, 0);
            endTime = new TimeSpan(0, 6, 0, 0);
            lLineRates.Add(new LineRate() { LineID = "G3", TimeRangeID = 24, TimeRangeStart = startTime, TimeRangeStop = endTime, LineRateForRangeID = 280, TimeRangeRateMultiplier = 1 });


        }
        public static void getLineRate(string sLineName)
        {
            try
            {
                List<LineRate> LR = new List<LineRate>();
                if (bNetworkConnected == true)
                {
                    LR = DB.LineProductionRates.Where(w => w.LineID == sLineName).Select(s => new LineRate { LineID = s.LineID, TimeRangeID = s.TimeRangeID, TimeRangeStart = s.TimeRangeStart, TimeRangeStop = s.TimeRangeStop, LineRateForRangeID = s.LineRateForRangeID, TimeRangeRateMultiplier = s.TimeRangeRateMultiplier }).ToList();
                }
                else
                {
                    LR = global.lLineRates.Where(w => w.LineID == sLineName).Select(s => new LineRate { LineID = s.LineID, TimeRangeID = s.TimeRangeID, TimeRangeStart = s.TimeRangeStart, TimeRangeStop = s.TimeRangeStop, LineRateForRangeID = s.LineRateForRangeID, TimeRangeRateMultiplier = s.TimeRangeRateMultiplier }).ToList();
                }

                foreach (var item in LR)
                {
                    item.LineHourlyGoal = Convert.ToInt32((item.LineRateForRangeID * item.TimeRangeRateMultiplier));
                }

                lLineRates = LR;
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine getLineRate with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine WriteBarIDToNetOutFile with the following error " + EX);
            }
            
        }
        public static void populateCurrentGridData()
        {
            string dtStartHour;
            string dtEndHour;
            //DateTime dToday = DateTime.Now.Date;
            DateTime dToday = DateTime.Now.Date.AddHours(5);
            DateTime dtStart = DateTime.Now.Date;
            DateTime dtEnd = DateTime.Now.Date.AddDays(1);
            var Completed = (dynamic)null;
            TimeSpan startTime = new TimeSpan(0, 0, 0, 0);
            TimeSpan endTime = new TimeSpan(0, 0, 0, 0);

            IEnumerable<tblGlassProduction> queryG = null;
            IEnumerable<tblWindowProduction> queryW = null;
            int iCompleted = 0;

            List<LineProductionRates> rates = new List<LineProductionRates>();
            List<LineProductionRates> tempList = new List<LineProductionRates>();
            frmMain main = new frmMain();

            UpdateMainFormElements UMFE = new UpdateMainFormElements(main);
            try
            {
                if (global.iCurrentHourRangeID <= 3)
                {
                    if (global.sLineType == "GLASS")
                    {
                        if(global.bNetworkConnected == true)
                        {
                            queryG = DB.tblGlassProduction.Where(w => w.TimeRangeID >= 1 && w.TimeRangeID <= 5 && w.ProductionDTS >= dToday && w.LineID == sSelectedLineName).ToList();
                        }
                        else
                        {
                            queryG = null;
                        }
                    }
                    else
                    {
                        if (global.bNetworkConnected == true)
                        {
                            queryW = DB.tblWindowProduction.Where(w => w.TimeRangeID >= 1 && w.TimeRangeID <= 5 && w.ProductionDTS >= dToday && w.LineID == sSelectedLineName).ToList();
                        }
                        else
                        {
                            queryW = null;
                        }
                    }
                    if(bNetworkConnected == true)
                    {
                        rates = DB.LineProductionRates.Where(w => w.TimeRangeID >= 1 && w.TimeRangeID <= 5 && w.LineID == sSelectedLineName).ToList();
                    }
                    else
                    {
                        var OfflineRates = lLineRates.Where(w => w.TimeRangeID >= 1 && w.TimeRangeID <= 5 && w.LineID == sSelectedLineName).ToList();
                        tempList.Clear();
                        foreach (var item in OfflineRates)
                        {
                            LineProductionRates LPR = new LineProductionRates();
                            LPR.LineID = item.LineID;
                            LPR.LineRateForRangeID = item.LineRateForRangeID;
                            LPR.TimeRangeID = item.TimeRangeID;
                            LPR.TimeRangeRateMultiplier = item.TimeRangeRateMultiplier;
                            LPR.TimeRangeStart = item.TimeRangeStart;
                            LPR.TimeRangeStop = item.TimeRangeStop;
                            tempList.Add(LPR);
                        }
                        rates = tempList;
                    }
                }

                if (global.iCurrentHourRangeID >= 4 && global.iCurrentHourRangeID <= 19)
                {
                    if (global.sLineType == "GLASS")
                    {
                        if(global.bNetworkConnected == true)
                        {
                            queryG = DB.tblGlassProduction.Where(w => w.TimeRangeID >= (iCurrentHourRangeID - 2) && w.TimeRangeID <= (iCurrentHourRangeID + 2) && w.ProductionDTS >= dToday && w.LineID == sSelectedLineName).ToList();
                        }
                        else
                        {
                            queryG = null;
                        }
                    }
                    else
                    {
                        if (global.bNetworkConnected == true)
                        {
                            queryW = DB.tblWindowProduction.Where(w => w.TimeRangeID >= (iCurrentHourRangeID - 2) && w.TimeRangeID <= (iCurrentHourRangeID + 2) && w.ProductionDTS >= dToday && w.LineID == sSelectedLineName).ToList();
                        }
                        else
                        {
                            queryW = null;
                        }
                    }
                    if(bNetworkConnected == true)
                    {
                        rates = DB.LineProductionRates.Where(w => w.TimeRangeID >= (iCurrentHourRangeID - 2) && w.TimeRangeID <= (iCurrentHourRangeID + 2) && w.LineID == sSelectedLineName).ToList();
                    }
                    else
                    {
                        var OfflineRates = lLineRates.Where(w => w.TimeRangeID >= (iCurrentHourRangeID - 2) && w.TimeRangeID <= (iCurrentHourRangeID + 2) && w.LineID == sSelectedLineName).ToList();
                        tempList.Clear();
                        foreach (var item in OfflineRates)
                        {
                            LineProductionRates LPR = new LineProductionRates();
                            LPR.LineID = item.LineID;
                            LPR.LineRateForRangeID = item.LineRateForRangeID;
                            LPR.TimeRangeID = item.TimeRangeID;
                            LPR.TimeRangeRateMultiplier = item.TimeRangeRateMultiplier;
                            LPR.TimeRangeStart = item.TimeRangeStart;
                            LPR.TimeRangeStop = item.TimeRangeStop;
                            tempList.Add(LPR);
                        }
                        rates = tempList;
                    }
                    
                }

                if (global.iCurrentHourRangeID >= 20 && global.iCurrentHourRangeID <= 24)
                {
                    if (global.sLineType == "GLASS")
                    {
                        if (global.bNetworkConnected == true)
                        {
                            queryG = DB.tblGlassProduction.Where(w => w.TimeRangeID >= 20 && w.TimeRangeID <= 24 && w.ProductionDTS >= dToday && w.LineID == sSelectedLineName).ToList();
                        }
                        else
                        {
                            queryG = null;
                        }
                        
                    }
                    else
                    {
                        if (global.bNetworkConnected == true)
                        {
                            queryW = DB.tblWindowProduction.Where(w => w.TimeRangeID >= 20 && w.TimeRangeID <= 24 && w.ProductionDTS >= dToday && w.LineID == sSelectedLineName).ToList();
                        }
                        else
                        {
                            queryW = null;
                        }
                    }
                    if(bNetworkConnected == true)
                    {
                        rates = DB.LineProductionRates.Where(w => w.TimeRangeID >= 20 && w.TimeRangeID <= 24 && w.LineID == sSelectedLineName).ToList();
                    }
                    else
                    {
                        var OfflineRates = lLineRates.Where(w => w.TimeRangeID >= 20 && w.TimeRangeID <= 24 && w.LineID == sSelectedLineName).ToList();
                        tempList.Clear();
                        foreach (var item in OfflineRates)
                        {
                            LineProductionRates LPR = new LineProductionRates();
                            LPR.LineID = item.LineID;
                            LPR.LineRateForRangeID = item.LineRateForRangeID;
                            LPR.TimeRangeID = item.TimeRangeID;
                            LPR.TimeRangeRateMultiplier = item.TimeRangeRateMultiplier;
                            LPR.TimeRangeStart = item.TimeRangeStart;
                            LPR.TimeRangeStop = item.TimeRangeStop;
                            tempList.Add(LPR);
                        }
                        rates = tempList;
                    }
                    
                }
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine populateCurrentGridData A with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine WriteBarIDToNetOutFile with the following error " + EX);
            }

            try
            {
                List<GridData> tempList2 = new List<GridData>();
                for (int i = 0; i < rates.Count; i++)
                {
                    GridData GD = new GridData();

                    if (sLineType == "GLASS")
                    {
                        if(queryG != null)
                        {
                            iCompleted = Convert.ToInt32(queryG.Where(w => w.TimeRangeID == rates[i].TimeRangeID).Select(s => s.QTY).FirstOrDefault());
                        }
                        else
                        {
                            iCompleted = 0;
                        }
                    }
                    else
                    {
                        if(queryW != null)
                        {
                            iCompleted = Convert.ToInt32(queryW.Where(w => w.TimeRangeID == rates[i].TimeRangeID).Select(s => s.QTY).FirstOrDefault());
                        }
                        else
                        {
                            iCompleted = 0;
                        }
                    }

                    if (iCompleted > 0)
                    {
                        GD.iRangeCompleted = iCompleted;
                        GD.iRangeDifferential = (iCompleted - Convert.ToInt32(rates.Where(w => w.TimeRangeID == rates[i].TimeRangeID).Select(s => (s.LineRateForRangeID * s.TimeRangeRateMultiplier)).FirstOrDefault()));
                    }
                    else
                    {
                        GD.iRangeCompleted = 0;
                        GD.iRangeDifferential = (0 - Convert.ToInt32(rates.Where(w => w.TimeRangeID == rates[i].TimeRangeID).Select(s => (s.LineRateForRangeID * s.TimeRangeRateMultiplier)).FirstOrDefault()));
                    }

                    GD.iRangeGoal = Convert.ToInt32(rates.Where(w => w.TimeRangeID == rates[i].TimeRangeID).Select(s => (s.LineRateForRangeID * s.TimeRangeRateMultiplier)).FirstOrDefault());

                    
                    startTime = new TimeSpan(0, Convert.ToInt32(rates[i].TimeRangeStart.TotalHours), 0, 0);
                    DateTime dtStarttime = DateTime.Today.Add(startTime);

                    endTime = new TimeSpan(0, Convert.ToInt32(rates[i].TimeRangeStop.TotalHours), 0, 0);
                    DateTime dtEndtime = DateTime.Today.Add(endTime);


                    dtStartHour = dtStarttime.ToString("h:mm tt");
                    dtEndHour = dtEndtime.ToString("h:mm tt");
                    GD.sHourRange = dtStartHour + " - " + dtEndHour;

                    tempList2.Add(GD);
                }
                lGridData = tempList2;
                UMFE.UpdateDGV();
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine populateCurrentGridData B with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine WriteBarIDToNetOutFile with the following error " + EX);
            }
        }
        public static void UpdateProductionCountDB()
        {
            DateTime dToday = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, 0, 0);
            DateTime dTodayStartHour = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, 0, 0);
            DateTime dTodayEndHour = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, 59, 59);
            var updateQuery = (dynamic)null;
            try
            {
                if (sLineType == "GLASS")
                {
                    //updateQuery = DB.tblGlassProduction.Where(w => w.TimeRangeID == iCurrentHourRangeID && w.LineID == sSelectedLineName && DateTime.Compare(w.ProductionDTS.Value, dToday) == 0).FirstOrDefault();
                    updateQuery = DB.tblGlassProduction.Where(w => w.TimeRangeID == iCurrentHourRangeID && w.LineID == sSelectedLineName && w.ProductionDTS.Value >= dTodayStartHour && w.ProductionDTS <= dTodayEndHour).FirstOrDefault();
                }
                else
                {
                    var AlreadyScanned = DB.barinv.Where(w => w.loadscandate >= DateTime.Today && w.id == global.iUnitID).ToList();
                    if(AlreadyScanned.Count == 0)
                    {
                        updateQuery = DB.tblWindowProduction.Where(w => w.TimeRangeID == iCurrentHourRangeID && w.LineID == sSelectedLineName && DateTime.Compare(w.ProductionDTS.Value, dToday) == 0).FirstOrDefault();
                        barinv UpdateProductionStatus = DB.barinv.Single(x => x.id == iUnitID);
                        //UpdateProductionStatus.loadscandate = DateTime.Now;
                        UpdateProductionStatus.loadscandate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, 0, 0);
                        DB.SaveChanges();
                    }
                    else
                    {
                        return;
                    }
                }

                if (updateQuery != null)
                {
                    updateQuery.QTY = updateQuery.QTY + 1;
                    iCurrentHourRangeCount = updateQuery.QTY;
                    DB.SaveChanges();
                }
                else
                {
                    if (sLineType == "GLASS")
                    {
                        tblGlassProduction GP = new tblGlassProduction();
                        GP.TimeRangeID = iCurrentHourRangeID;
                        GP.LineID = sSelectedLineName;
                        GP.ProductionDTS = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, 0, 0);
                        GP.QTY = iCurrentHourRangeCount;
                        DB.tblGlassProduction.Add(GP);
                        DB.SaveChanges();
                    }
                    else
                    {
                        tblWindowProduction WP = new tblWindowProduction();
                        WP.TimeRangeID = iCurrentHourRangeID;
                        WP.LineID = sSelectedLineName;
                        WP.ProductionDTS = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, DateTime.Now.Hour, 0, 0);
                        WP.QTY = iCurrentHourRangeCount;
                        DB.tblWindowProduction.Add(WP);
                        DB.SaveChanges();
                    }
                }
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine UpdateDB66 with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine WriteBarIDToNetOutFile with the following error " + EX);
            }
            
        }
        public static void PopulateLineNames()
        {
            try
            {
                List<LineNames> linesTemp = new List<LineNames>();

                linesTemp.Add(new LineNames() { LineName = "WINDOWS - LINE 1", LineValue = "V1" });
                linesTemp.Add(new LineNames() { LineName = "WINDOWS - LINE 2", LineValue = "V2" });
                linesTemp.Add(new LineNames() { LineName = "WINDOWS - LINE 3", LineValue = "V3" });
                linesTemp.Add(new LineNames() { LineName = "WINDOWS - LINE 4", LineValue = "V5" });
                linesTemp.Add(new LineNames() { LineName = "WINDOWS - LINE 5", LineValue = "A1" });
                linesTemp.Add(new LineNames() { LineName = "WINDOWS - LINE 6", LineValue = "A3" });
                linesTemp.Add(new LineNames() { LineName = "WINDOWS - SHAPES", LineValue = "V4" });
                linesTemp.Add(new LineNames() { LineName = "GLASS - LINE 1", LineValue = "G1" });
                linesTemp.Add(new LineNames() { LineName = "GLASS - LINE 2", LineValue = "G2" });
                linesTemp.Add(new LineNames() { LineName = "GLASS - LINE 3", LineValue = "G3" });
                LineNames = linesTemp;
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine PopulateLineNames with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine PopulateLineNames with the following error " + EX);
            }

        }

        public static void WriteCountToOutputFile()
        {
            try
            {
                using (StreamWriter w = File.AppendText(global.sCountOutputFile))
                {
                    w.WriteLine(global.sLineType + "||" + sSelectedLineName + "||" + DateTime.Now.ToShortDateString() + "||" + iCurrentHourRangeID + "||" + iCurrentHourRangeCount);
                }
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine WriteGlassCountToOutputFile with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine WriteBarIDToNetOutFile with the following error " + EX);
            }
        }
        public static void WriteWindowOutputFile()
        {
            try
            {
                using (StreamWriter w = File.AppendText(global.sWindowOutputFile))
                {
                    w.WriteLine(iUnitID + "||" + iNFRC + "||" + DateTime.Now.ToShortDateString() + "||" + global.iCurrentHourRangeID);
                }
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine WriteWindowCountToOutputFile with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine WriteBarIDToNetOutFile with the following error " + EX);
            }
        }
        public static void UpdateDBFromOutputFiles()
        {
            int ID = 0;
            int hourID = 0;
            DateTime dtToday = DateTime.Today;
            DateTime dtFileDate;
            string sProductionType = "";
            int QTY = 0;
            try
            {
                //Read Counts from Count File and Update Count Tables
                #region UPDATE COUNTS TO COUNT TABLES
                //IF THE COUNT OUTPUT FILE EXISTS
                if (File.Exists(global.sCountOutputFile))
                {
                    var readlogFile = File.ReadAllLines(global.sCountOutputFile).ToList();
                    //IF THE WINDOWS OUTPUT FILE IS NOT EMPTY
                    if (readlogFile.Count > 0)
                    {
                        foreach (var item in readlogFile)
                        {
                            hourID = Convert.ToInt32(Regex.Split(item, "||")[3]);
                            dtFileDate = Convert.ToDateTime(Regex.Split(item, "||")[2]);
                            sProductionType = Regex.Split(item, "||")[0];
                            QTY = Convert.ToInt32(Regex.Split(item, "||")[4]);
                            if (Regex.Split(item, "||")[1] == global.sSelectedLineName && dtFileDate >= dtToday)
                            {
                                if(sProductionType == "WINDOW")
                                {
                                    //UPDATE EXISTING RECORD
                                    tblWindowProduction UPDATE = DB.tblWindowProduction.Where(w => w.LineID == global.sSelectedLineName && w.ProductionDTS >= dtFileDate && w.TimeRangeID == hourID).FirstOrDefault();
                                    if(UPDATE != null)
                                    {
                                        UPDATE.QTY = UPDATE.QTY + QTY;
                                        DB.SaveChanges();
                                    }
                                    else
                                    {
                                        //CREATE NEW RECORD
                                        tblWindowProduction CREATE = new tblWindowProduction();
                                        CREATE.LineID = global.sSelectedLineName;
                                        CREATE.ProductionDTS = dtToday;
                                        CREATE.QTY = QTY;
                                        CREATE.TimeRangeID = hourID;
                                        DB.tblWindowProduction.Add(CREATE);
                                        DB.SaveChanges();
                                    }
                                }
                                else
                                {
                                    //UPDATE EXISTING RECORD
                                    tblGlassProduction UPDATE = DB.tblGlassProduction.Where(w => w.LineID == global.sSelectedLineName && w.ProductionDTS >= dtFileDate && w.TimeRangeID == hourID).FirstOrDefault();
                                    if (UPDATE != null)
                                    {
                                        UPDATE.QTY = UPDATE.QTY + QTY;
                                        DB.SaveChanges();
                                    }
                                    else
                                    {
                                        //CREATE NEW RECORD
                                        tblGlassProduction CREATE = new tblGlassProduction();
                                        CREATE.LineID = global.sSelectedLineName;
                                        CREATE.ProductionDTS = dtToday;
                                        CREATE.QTY = QTY;
                                        CREATE.TimeRangeID = hourID;
                                        DB.tblGlassProduction.Add(CREATE);
                                        DB.SaveChanges();
                                    }
                                }
                            }
                        }
                        File.WriteAllText(global.sCountOutputFile, String.Empty);
                    }

                }
                #endregion

                //Update Barinv from Offline File
                #region UPDATE BARINV FROM FILE
                if (global.sLineType == "WINDOW")
                {
                    //IF THE WINDOW OUTPUT FILE EXISTS
                    if (File.Exists(global.sWindowOutputFile))
                    {
                        var readlogFile = File.ReadAllLines(global.sWindowOutputFile).ToList();
                        //IF THE WINDOWS OUTPUT FILE IS NOT EMPTY
                        if (readlogFile.Count > 0)
                        {
                            //Read file into database
                            foreach (var item in readlogFile)
                            {
                                ID = Convert.ToInt32(Regex.Split(item, "||")[0]);
                                barinv update = DB.barinv.Where(w => w.id == ID).FirstOrDefault();
                                update.loadscandate = DateTime.Now;
                                update.status = "Produced TSHOWN";
                                DB.SaveChanges();
                            }
                            File.WriteAllText(global.sWindowOutputFile, String.Empty);
                        }
                    }
                }
                #endregion
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine UpdateDBFromOutputFile with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine frmMAIN_Load with the following error " + EX);
            }
        }
        #endregion
    }

    public class LineRate
    {
        public string LineID { get; set; }
        public int TimeRangeID { get; set; }
        public TimeSpan TimeRangeStart { get; set; }
        public TimeSpan TimeRangeStop { get; set; }
        public int LineRateForRangeID { get; set; }
        public decimal TimeRangeRateMultiplier { get; set; }
        public int LineHourlyGoal { get; set; }
        public int CompletedUnitsThisHour { get; set; }

        public void UpdateWindowFile(string FilePath, string SelectedLine, int CurrentHourID, string BarID)
        {
            using (StreamWriter sw = (File.Exists(FilePath)) ? File.AppendText(FilePath) : File.CreateText(FilePath))
            {
                    sw.WriteLine(SelectedLine + "||" + CurrentHourID + "||" + BarID + "||" + DateTime.Now);
            }
        }

        public void UpdateCountFile(string FilePath, string SelectedLine, int CurrentHourID, int CurrentCount)
        {
            using (StreamWriter sw = (File.Exists(FilePath)) ? File.AppendText(FilePath) : File.CreateText(FilePath))
            {
                sw.WriteLine(SelectedLine + "||" + CurrentHourID + "||" + CurrentCount + "||" + DateTime.Now);
            }
        }

        public void ReadFileToList(string FilePath)
        {
            global.lFileContents = File.ReadAllLines(FilePath).ToList();
        }
    }
    public class GridData
    {
        public string sHourRange { get; set; }
        public int iRangeGoal { get; set; }
        public int iRangeCompleted { get; set; }
        public int iRangeDifferential { get; set; }
    }
    public class LineNames
    {
        public string LineName { get; set; }
        public string LineValue { get; set; }
    }
}
