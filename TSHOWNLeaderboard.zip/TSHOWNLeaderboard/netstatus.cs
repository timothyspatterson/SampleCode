﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TSHOWNLeaderboard
{
    public class netstatus
    {
        public static ILog log = LogManager.GetLogger("log");
        public static bool bNetworkIssue { get; set; }
        public bool Bnetstatus()
        {
            try
            {
                using (var client = new WebClient())
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        public static void GetNetStatus()
        {

            try
            {
                using (var client = new WebClient())
                using (var stream = client.OpenRead("http://google.com/generate_204"))
                {
                    global.bNetworkConnected = true;
                }
            }
            catch
            {
                global.bNetworkConnected = false;
            }

            try
            {
                if ( global.bNetworkConnected == false)
                {
                    try
                    {
                        bNetworkIssue = true;
                    }
                    catch (Exception objEx)
                    {
                        MessageBox.Show(objEx.ToString());
                    }
                }
                else
                {
                    bNetworkIssue = false;
                }
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine NetworkStatus with the following error " + EX);
                //MessageBox.Show("I have failed in subroutine NetworkStatus with the following error " + EX);
            }
        }
    }
}
