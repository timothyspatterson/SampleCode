﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TSHOWNLeaderboard
{
    class print
    {
        public static ILog log = LogManager.GetLogger("log");
        //Printer Helper that routes the print job to the attached Zebra
        //Logging - Enabled
        public void PrintToShared(String printerAddress, String text, String documentName)
        {
            IntPtr printer = new IntPtr();

            try
            {
                // A pointer to a value that receives the number of bytes of data that were written to the printer.
                int pcWritten = 0;

                Helper.DOCINFO docInfo = new Helper.DOCINFO();
                docInfo.pDocName = documentName;
                docInfo.pDataType = "RAW";

                Helper.PrintDirect.OpenPrinter(printerAddress, ref printer, 0);
                Helper.PrintDirect.StartDocPrinter(printer, 1, ref docInfo);
                Helper.PrintDirect.StartPagePrinter(printer);

                try
                {
                    Helper.PrintDirect.WritePrinter(printer, text, text.Length, ref pcWritten);
                }
                catch (Exception ex)
                {
                    log.Error(ex);
                }

                Helper.PrintDirect.EndPagePrinter(printer);
                Helper.PrintDirect.EndDocPrinter(printer);
                Helper.PrintDirect.ClosePrinter(printer);
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine PrintToShared with the following error " + EX);
                MessageBox.Show("I have failed in subroutine PrintToShared with the following error " + EX);
            }
        }
    }
}
