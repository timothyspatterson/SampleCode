﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TSHOWNLeaderboard
{
    class processNFRC
    {
        public static List<NFRCRecord> NFRCValues;
        public static int CurrentNFRCid { get; set; }
        public static string LabelBlock { get; set; }
        public static ILog log = LogManager.GetLogger("log");
        ProductionValidationEntities DB = new ProductionValidationEntities();

        //Hard-coded list of NFRC table as of 04-15-2019
        //Logging - Disabled
        public static void createNFRCList()
        {
            try
            {
                List<NFRCRecord> nfrcTemp = new List<NFRCRecord>();
                //nfrcTemp.Add(new NFRCRecord() { NFRCID = 16001, SCHKey = "4101NL3", uFactor = 0.33, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "0.3", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-7-00022-00001", GT = "SSB" });

                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16001, SCHKey = "4101NL3", uFactor = 0.33, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-26-00014-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16002, SCHKey = "4101NL3Y", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-26-00020-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16003, SCHKey = "4101YL3", uFactor = 0.33, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-26-00014-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16004, SCHKey = "4101YL3Y", uFactor = 0.29, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-26-00020-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16005, SCHKey = "4120NL3", uFactor = 0.33, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-7-00034-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16006, SCHKey = "4120NL3Y", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-7-00038-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16007, SCHKey = "4120YL3", uFactor = 0.33, SolarHeat = 0.21, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-7-00034-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16008, SCHKey = "4120YL3Y", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-7-00038-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16009, SCHKey = "4101NL3-2", uFactor = 0.33, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-26-00014-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16010, SCHKey = "4101NL3Y-2", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-26-00020-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16011, SCHKey = "4101YL3-2", uFactor = 0.33, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-26-00014-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16012, SCHKey = "4101YL3Y-2", uFactor = 0.29, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-26-00020-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16013, SCHKey = "4120NL3-2", uFactor = 0.33, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-7-00034-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16014, SCHKey = "4120NL3Y-2", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-7-00038-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16015, SCHKey = "4120YL3-2", uFactor = 0.33, SolarHeat = 0.21, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-7-00034-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16016, SCHKey = "4120YL3Y-2", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-7-00038-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16017, SCHKey = "4101NL3-3", uFactor = 0.32, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-26-00017-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16018, SCHKey = "4101NL3Y-3", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-26-00023-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16019, SCHKey = "4101YL3-3", uFactor = 0.32, SolarHeat = 0.21, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-26-00017-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16020, SCHKey = "4101YL3Y-3", uFactor = 0.29, SolarHeat = 0.21, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-26-00023-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16021, SCHKey = "4120NL3-3", uFactor = 0.33, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-7-00036-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16022, SCHKey = "4120NL3Y-3", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-7-00040-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16023, SCHKey = "4120YL3-3", uFactor = 0.33, SolarHeat = 0.21, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-7-00036-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16024, SCHKey = "4120YL3Y-3", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-7-00040-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16025, SCHKey = "9801NL3", uFactor = 0.33, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-19-00061-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16026, SCHKey = "9801NL3-2", uFactor = 0.33, SolarHeat = 0.24, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-19-00061-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16027, SCHKey = "9801NL3-3", uFactor = 0.34, SolarHeat = 0.24, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-19-00065-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16028, SCHKey = "9801NL3Y", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-19-00062-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16029, SCHKey = "9801NL3Y-2", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-19-00062-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16030, SCHKey = "9801NL3Y-3", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-19-00066-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16031, SCHKey = "9801YL3", uFactor = 0.33, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-19-00061-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16032, SCHKey = "9801YL3-2", uFactor = 0.33, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-19-00061-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16033, SCHKey = "9801YL3-3", uFactor = 0.37, SolarHeat = 0.22, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-19-00072-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16034, SCHKey = "9801YL3Y", uFactor = 0.29, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-19-00062-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16035, SCHKey = "9801YL3Y-2", uFactor = 0.29, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-19-00062-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16036, SCHKey = "9801YL3Y-3", uFactor = 0.32, SolarHeat = 0.21, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-19-00074-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16037, SCHKey = "9810NL3", uFactor = 0.35, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-17-00061-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16038, SCHKey = "9810NL3-2", uFactor = 0.35, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-17-00061-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16039, SCHKey = "9810NL3-3", uFactor = 0.35, SolarHeat = 0.23, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-17-00065-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16040, SCHKey = "9810NL3Y", uFactor = 0.31, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-17-00062-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16041, SCHKey = "9810NL3Y-2", uFactor = 0.31, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-17-00062-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16042, SCHKey = "9810NL3Y-3", uFactor = 0.31, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-17-00066-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16043, SCHKey = "9810YL3", uFactor = 0.35, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-17-00061-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16044, SCHKey = "9810YL3-2", uFactor = 0.35, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-17-00061-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16045, SCHKey = "9810YL3-3", uFactor = 0.31, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-17-00062-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16046, SCHKey = "9810YL3Y", uFactor = 0.31, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-17-00062-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16047, SCHKey = "9810YL3Y-2", uFactor = 0.31, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-17-00062-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16048, SCHKey = "9810YL3Y-3", uFactor = 0.31, SolarHeat = 0.2, LightTrans = 0.45, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-17-00066-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16049, SCHKey = "9820NL3", uFactor = 0.35, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-18-00053-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16050, SCHKey = "9820NL3-2", uFactor = 0.35, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-18-00053-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16051, SCHKey = "9820NL3Y", uFactor = 0.31, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-18-00054-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16052, SCHKey = "9820NL3Y-2", uFactor = 0.31, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-18-00054-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16053, SCHKey = "9820YL3", uFactor = 0.35, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-18-00053-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16054, SCHKey = "9820YL3-2", uFactor = 0.35, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-18-00053-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16055, SCHKey = "9820YL3Y", uFactor = 0.31, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-18-00054-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16056, SCHKey = "9820YL3Y-2", uFactor = 0.31, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-18-00054-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16057, SCHKey = "2-9801NL3", uFactor = 0.33, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-19-00061-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16058, SCHKey = "2-9801NL3-2", uFactor = 0.33, SolarHeat = 0.24, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-19-00061-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16059, SCHKey = "2-9801NL3-3", uFactor = 0.34, SolarHeat = 0.24, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-19-00065-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16060, SCHKey = "2-9801NL3Y", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-19-00062-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16061, SCHKey = "2-9801NL3Y-2", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-19-00062-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16062, SCHKey = "2-9801NL3Y-3", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-19-00066-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16063, SCHKey = "2-9801YL3", uFactor = 0.33, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-19-00061-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16064, SCHKey = "2-9801YL3-2", uFactor = 0.33, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-19-00061-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16065, SCHKey = "2-9801YL3-3", uFactor = 0.37, SolarHeat = 0.22, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-19-00072-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16066, SCHKey = "2-9801YL3Y", uFactor = 0.29, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-19-00062-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16067, SCHKey = "2-9801YL3Y-2", uFactor = 0.29, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-19-00062-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16068, SCHKey = "2-9801YL3Y-3", uFactor = 0.32, SolarHeat = 0.21, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-19-00074-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16069, SCHKey = "2-9810NL3", uFactor = 0.35, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-17-00061-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16070, SCHKey = "2-9810NL3-2", uFactor = 0.35, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-17-00061-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16071, SCHKey = "2-9810NL3-3", uFactor = 0.35, SolarHeat = 0.23, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-17-00065-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16072, SCHKey = "2-9810NL3Y", uFactor = 0.31, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-17-00062-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16073, SCHKey = "2-9810NL3Y-2", uFactor = 0.31, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-17-00062-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16074, SCHKey = "2-9810NL3Y-3", uFactor = 0.31, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-17-00066-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16075, SCHKey = "2-9810YL3", uFactor = 0.35, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-17-00061-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16076, SCHKey = "2-9810YL3-2", uFactor = 0.35, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-17-00061-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16077, SCHKey = "2-9810YL3-3", uFactor = 0.35, SolarHeat = 0.2, LightTrans = 0.45, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-17-00065-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16078, SCHKey = "2-9810YL3Y", uFactor = 0.31, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-17-00062-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16079, SCHKey = "2-9810YL3Y-2", uFactor = 0.31, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-17-00062-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16080, SCHKey = "2-9810YL3Y-3", uFactor = 0.31, SolarHeat = 0.2, LightTrans = 0.45, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-17-00066-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16081, SCHKey = "3-9801NL3", uFactor = 0.33, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-19-00061-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16082, SCHKey = "3-9801NL3-2", uFactor = 0.33, SolarHeat = 0.24, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-19-00061-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16083, SCHKey = "3-9801NL3-3", uFactor = 0.34, SolarHeat = 0.24, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-19-00065-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16084, SCHKey = "3-9801NL3Y", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-19-00062-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16085, SCHKey = "3-9801NL3Y-2", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-19-00062-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16086, SCHKey = "3-9801NL3Y-3", uFactor = 0.29, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-19-00066-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16087, SCHKey = "3-9801YL3", uFactor = 0.33, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-19-00061-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16088, SCHKey = "3-9801YL3-2", uFactor = 0.33, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-19-00061-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16089, SCHKey = "3-9801YL3-3", uFactor = 0.37, SolarHeat = 0.22, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-19-00072-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16090, SCHKey = "3-9801YL3Y", uFactor = 0.29, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-19-00062-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16091, SCHKey = "3-9801YL3Y-2", uFactor = 0.29, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-19-00062-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16092, SCHKey = "3-9801YL3Y-3", uFactor = 0.32, SolarHeat = 0.21, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-19-00074-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16093, SCHKey = "3-9810NL3", uFactor = 0.35, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-17-00061-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16094, SCHKey = "3-9810NL3-2", uFactor = 0.35, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-17-00061-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16095, SCHKey = "3-9810NL3-3", uFactor = 0.35, SolarHeat = 0.23, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids ", Desc4 = "BFS-A-17-00065-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16096, SCHKey = "3-9810NL3Y", uFactor = 0.31, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-17-00062-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16097, SCHKey = "3-9810NL3Y-2", uFactor = 0.31, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-17-00062-00005", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16098, SCHKey = "3-9810NL3Y-3", uFactor = 0.31, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  No Grids Argon", Desc4 = "BFS-A-17-00066-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16099, SCHKey = "3-9810YL3", uFactor = 0.35, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-17-00061-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16100, SCHKey = "3-9810YL3-2", uFactor = 0.35, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-17-00061-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16101, SCHKey = "3-9810YL3-3", uFactor = 0.35, SolarHeat = 0.2, LightTrans = 0.45, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids ", Desc4 = "BFS-A-17-00065-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16102, SCHKey = "3-9810YL3Y", uFactor = 0.31, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-17-00062-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16103, SCHKey = "3-9810YL3Y-2", uFactor = 0.31, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-17-00062-00006", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16104, SCHKey = "3-9810YL3Y-3", uFactor = 0.31, SolarHeat = 0.2, LightTrans = 0.45, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022)  With Grids Argon", Desc4 = "BFS-A-17-00066-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16105, SCHKey = "T4101NL3", uFactor = 0.31, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-26-00026-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16106, SCHKey = "T4101NL3Y", uFactor = 0.27, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-26-00030-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16107, SCHKey = "T4101YL3", uFactor = 0.31, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-26-00026-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16108, SCHKey = "T4101YL3Y", uFactor = 0.27, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-26-00030-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16109, SCHKey = "T4120NL3", uFactor = 0.31, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-7-00042-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16110, SCHKey = "T4120NL3Y", uFactor = 0.27, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-7-00046-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16111, SCHKey = "T4120YL3", uFactor = 0.31, SolarHeat = 0.21, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-7-00042-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16112, SCHKey = "T4120YL3Y", uFactor = 0.27, SolarHeat = 0.2, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-7-00046-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16113, SCHKey = "T4101NL3-2", uFactor = 0.31, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-26-00028-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16114, SCHKey = "T4101NL3Y-2", uFactor = 0.27, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-26-00032-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16115, SCHKey = "T4101YL3-2", uFactor = 0.31, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-26-00028-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16116, SCHKey = "T4101YL3Y-2", uFactor = 0.27, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-26-00032-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16117, SCHKey = "T4120NL3-2", uFactor = 0.31, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-7-00044-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16118, SCHKey = "T4120NL3Y-2", uFactor = 0.27, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-7-00048-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16119, SCHKey = "T4120YL3-2", uFactor = 0.31, SolarHeat = 0.21, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-7-00044-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16120, SCHKey = "T4120YL3Y-2", uFactor = 0.27, SolarHeat = 0.2, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-7-00048-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16121, SCHKey = "T4101NL3-3", uFactor = 0.31, SolarHeat = 0.24, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-26-00029-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16122, SCHKey = "T4101NL3Y-3", uFactor = 0.27, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-26-00033-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16123, SCHKey = "T4101YL3-3", uFactor = 0.31, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-26-00029-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16124, SCHKey = "T4101YL3Y-3", uFactor = 0.27, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 3101 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-26-00033-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16125, SCHKey = "T4120NL3-3", uFactor = 0.32, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-7-00045-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16126, SCHKey = "T4120NL3Y-3", uFactor = 0.27, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-7-00049-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16127, SCHKey = "T4120YL3-3", uFactor = 0.32, SolarHeat = 0.21, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-7-00045-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16128, SCHKey = "T4120YL3Y-3", uFactor = 0.27, SolarHeat = 0.21, LightTrans = 0.47, AirVal = "-", Desc1 = "SERIES 3120 SLIDING DOOR", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-7-00049-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16129, SCHKey = "T9801NL3", uFactor = 0.32, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-19-00076-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16130, SCHKey = "T9801NL3-2", uFactor = 0.32, SolarHeat = 0.24, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-19-00078-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16131, SCHKey = "T9801NL3-3", uFactor = 0.33, SolarHeat = 0.24, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-19-00079-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16132, SCHKey = "T9801NL3Y", uFactor = 0.28, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-19-00080-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16133, SCHKey = "T9801NL3Y-2", uFactor = 0.28, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-19-00082-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16134, SCHKey = "T9801NL3Y-3", uFactor = 0.28, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-19-00083-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16135, SCHKey = "T9801YL3", uFactor = 0.32, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-19-00076-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16136, SCHKey = "T9801YL3-2", uFactor = 0.32, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-19-00078-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16137, SCHKey = "T9801YL3-3", uFactor = 0.33, SolarHeat = 0.22, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-19-00079-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16138, SCHKey = "T9801YL3Y", uFactor = 0.28, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-19-00080-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16139, SCHKey = "T9801YL3Y-2", uFactor = 0.28, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-19-00082-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16140, SCHKey = "T9801YL3Y-3", uFactor = 0.28, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-19-00083-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16141, SCHKey = "T9810NL3", uFactor = 0.33, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-17-00076-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16142, SCHKey = "T9810NL3-2", uFactor = 0.33, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-17-00078-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16143, SCHKey = "T9810NL3-3", uFactor = 0.34, SolarHeat = 0.23, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-17-00079-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16144, SCHKey = "T9810NL3Y", uFactor = 0.29, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-17-00080-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16145, SCHKey = "T9810NL3Y-2", uFactor = 0.29, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-17-00082-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16146, SCHKey = "T9810NL3Y-3", uFactor = 0.29, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-17-00083-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16147, SCHKey = "T9810YL3", uFactor = 0.33, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-17-00076-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16148, SCHKey = "T9810YL3-2", uFactor = 0.33, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-17-00078-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16149, SCHKey = "T9810YL3-3", uFactor = 0.34, SolarHeat = 0.21, LightTrans = 0.45, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-17-00079-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16150, SCHKey = "T9810YL3Y", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-17-00080-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16151, SCHKey = "T9810YL3Y-2", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-17-00082-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16152, SCHKey = "T9810YL3Y-3", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.45, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-17-00083-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16153, SCHKey = "T9820NL3", uFactor = 0.33, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-18-00068-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16154, SCHKey = "T9820NL3-2", uFactor = 0.33, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-18-00070-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16155, SCHKey = "T9820NL3Y", uFactor = 0.3, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-18-00072-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16156, SCHKey = "T9820NL3Y-2", uFactor = 0.29, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-18-00074-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16157, SCHKey = "T9820YL3", uFactor = 0.33, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-18-00068-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16158, SCHKey = "T9820YL3-2", uFactor = 0.33, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-18-00070-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16159, SCHKey = "T9820YL3Y", uFactor = 0.3, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-18-00072-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16160, SCHKey = "T9820YL3Y-2", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9820 SLIDER", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-18-00074-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16161, SCHKey = "T2-9801NL3", uFactor = 0.32, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-19-00076-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16162, SCHKey = "T2-9801NL3-2", uFactor = 0.32, SolarHeat = 0.24, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-19-00078-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16163, SCHKey = "T2-9801NL3-3", uFactor = 0.33, SolarHeat = 0.24, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-19-00079-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16164, SCHKey = "T2-9801NL3Y", uFactor = 0.28, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-19-00080-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16165, SCHKey = "T2-9801NL3Y-2", uFactor = 0.28, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-19-00082-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16166, SCHKey = "T2-9801NL3Y-3", uFactor = 0.28, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-19-00083-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16167, SCHKey = "T2-9801YL3", uFactor = 0.32, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-19-00076-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16168, SCHKey = "T2-9801YL3-2", uFactor = 0.32, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-19-00078-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16169, SCHKey = "T2-9801YL3-3", uFactor = 0.33, SolarHeat = 0.22, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-19-00079-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16170, SCHKey = "T2-9801YL3Y", uFactor = 0.28, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-19-00080-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16171, SCHKey = "T2-9801YL3Y-2", uFactor = 0.28, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-19-00082-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16172, SCHKey = "T2-9801YL3Y-3", uFactor = 0.28, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-19-00083-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16173, SCHKey = "T2-9810NL3", uFactor = 0.33, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-17-00076-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16174, SCHKey = "T2-9810NL3-2", uFactor = 0.33, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-17-00078-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16175, SCHKey = "T2-9810NL3-3", uFactor = 0.34, SolarHeat = 0.23, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-17-00079-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16176, SCHKey = "T2-9810NL3Y", uFactor = 0.29, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-17-00080-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16177, SCHKey = "T2-9810NL3Y-2", uFactor = 0.29, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-17-00082-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16178, SCHKey = "T2-9810NL3Y-3", uFactor = 0.29, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-17-00083-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16179, SCHKey = "T2-9810YL3", uFactor = 0.33, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-17-00076-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16180, SCHKey = "T2-9810YL3-2", uFactor = 0.33, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-17-00078-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16181, SCHKey = "T2-9810YL3-3", uFactor = 0.34, SolarHeat = 0.21, LightTrans = 0.45, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-17-00079-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16182, SCHKey = "T2-9810YL3Y", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-17-00080-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16183, SCHKey = "T2-9810YL3Y-2", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-17-00082-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16184, SCHKey = "T2-9810YL3Y-3", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.45, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-17-00083-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16185, SCHKey = "T3-9801NL3", uFactor = 0.32, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-19-00076-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16186, SCHKey = "T3-9801NL3-2", uFactor = 0.32, SolarHeat = 0.24, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-19-00078-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16187, SCHKey = "T3-9801NL3-3", uFactor = 0.33, SolarHeat = 0.24, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-19-00079-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16188, SCHKey = "T3-9801NL3Y", uFactor = 0.28, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-19-00080-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16189, SCHKey = "T3-9801NL3Y-2", uFactor = 0.28, SolarHeat = 0.23, LightTrans = 0.54, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-19-00082-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16190, SCHKey = "T3-9801NL3Y-3", uFactor = 0.28, SolarHeat = 0.23, LightTrans = 0.53, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-19-00083-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16191, SCHKey = "T3-9801YL3", uFactor = 0.32, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-19-00076-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16192, SCHKey = "T3-9801YL3-2", uFactor = 0.32, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-19-00078-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16193, SCHKey = "T3-9801YL3-3", uFactor = 0.33, SolarHeat = 0.22, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-19-00079-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16194, SCHKey = "T3-9801YL3Y", uFactor = 0.28, SolarHeat = 0.21, LightTrans = 0.49, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-19-00080-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16195, SCHKey = "T3-9801YL3Y-2", uFactor = 0.28, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-19-00082-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16196, SCHKey = "T3-9801YL3Y-3", uFactor = 0.28, SolarHeat = 0.21, LightTrans = 0.48, AirVal = "-", Desc1 = "SERIES 9801 FIXED", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-19-00083-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16197, SCHKey = "T3-9810NL3", uFactor = 0.33, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-17-00076-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16198, SCHKey = "T3-9810NL3-2", uFactor = 0.33, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-17-00078-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16199, SCHKey = "T3-9810NL3-3", uFactor = 0.34, SolarHeat = 0.23, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids ", Desc4 = "BFS-A-17-00079-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16200, SCHKey = "T3-9810NL3Y", uFactor = 0.29, SolarHeat = 0.22, LightTrans = 0.52, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-17-00080-00001", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16201, SCHKey = "T3-9810NL3Y-2", uFactor = 0.29, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-17-00082-00001", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16202, SCHKey = "T3-9810NL3Y-3", uFactor = 0.29, SolarHeat = 0.22, LightTrans = 0.51, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  No Grids Argon", Desc4 = "BFS-A-17-00083-00001", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16203, SCHKey = "T3-9810YL3", uFactor = 0.33, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-17-00076-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16204, SCHKey = "T3-9810YL3-2", uFactor = 0.33, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-17-00078-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16205, SCHKey = "T3-9810YL3-3", uFactor = 0.34, SolarHeat = 0.21, LightTrans = 0.45, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids ", Desc4 = "BFS-A-17-00079-00002", GT = "3/16" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16206, SCHKey = "T3-9810YL3Y", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-17-00080-00002", GT = "SSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16207, SCHKey = "T3-9810YL3Y-2", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.46, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-17-00082-00002", GT = "DSB" });
                nfrcTemp.Add(new NFRCRecord() { NFRCID = 16208, SCHKey = "T3-9810YL3Y-3", uFactor = 0.29, SolarHeat = 0.2, LightTrans = 0.45, AirVal = "-", Desc1 = "SERIES 9810 SINGLE HUNG", Desc2 = "VINYL FRAME DOUBLE GLAZE", Desc3 = "Loe366 (0.022) Thermoplastic  With Grids Argon", Desc4 = "BFS-A-17-00083-00002", GT = "3/16" });

                NFRCValues = nfrcTemp;
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine createNFRCList with the following error " + EX);
                MessageBox.Show("I have failed in subroutine createNFRCList with the following error " + EX);
            }

        }

        //Prints the NFRC label to the attached Zebra printer
        //Logging - Enabled
        public static void createNFRCLabel()
        {
            global global = new global();
            string ID = global.iUnitID.ToString();
            
            //bool netConnected = false;
            //netConnected = Global.checkDBConnection();
            List<NFRCRecord> nfrcDetails = new List<NFRCRecord>();
            NFRCRecord NFRCRec = new NFRCRecord();
            ProductionValidationEntities DB = new ProductionValidationEntities();
            try
            {
                if (global.bNetworkConnected == true)
                {
                    if (!DB.NFRC.Any(x => x.NFRCID == CurrentNFRCid))
                    {
                        CurrentNFRCid = 16001;
                    }
                    var results = DB.NFRC.Where(y => y.NFRCID == CurrentNFRCid).FirstOrDefault();
                    NFRCRec.NFRCID = results.NFRCID;
                    NFRCRec.SCHKey = results.SCHKey;
                    NFRCRec.uFactor = Convert.ToDouble(results.uFactor);
                    NFRCRec.SolarHeat = Convert.ToDouble(results.SolarHeat);
                    NFRCRec.LightTrans = Convert.ToDouble(results.LightTrans);
                    NFRCRec.AirVal = results.AirVal;
                    NFRCRec.Desc1 = results.Desc1;
                    NFRCRec.Desc2 = results.Desc2;
                    NFRCRec.Desc3 = results.Desc3;
                    NFRCRec.Desc4 = results.Desc4;
                    NFRCRec.GT = results.GT;

                    nfrcDetails.Add(NFRCRec);
                }
                else
                {
                    if (CurrentNFRCid <= 0)
                    {
                        CurrentNFRCid = 16001;
                    }

                    var results = NFRCValues.Where(w => w.NFRCID == CurrentNFRCid).FirstOrDefault();
                    if(results == null)
                    {
                        results = NFRCValues.Where(w => w.NFRCID == 16001).FirstOrDefault();
                    }
                    NFRCRec.NFRCID = results.NFRCID;
                    NFRCRec.SCHKey = results.SCHKey;
                    NFRCRec.uFactor = Convert.ToDouble(results.uFactor);
                    NFRCRec.SolarHeat = Convert.ToDouble(results.SolarHeat);
                    NFRCRec.LightTrans = Convert.ToDouble(results.LightTrans);
                    NFRCRec.AirVal = results.AirVal;
                    NFRCRec.Desc1 = results.Desc1;
                    NFRCRec.Desc2 = results.Desc2;
                    NFRCRec.Desc3 = results.Desc3;
                    NFRCRec.Desc4 = results.Desc4;
                    NFRCRec.GT = results.GT;

                    nfrcDetails.Add(NFRCRec);
                }
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine createNFRCLabel gathering label data with the following error " + EX);
                MessageBox.Show("I have failed in subroutine createNFRCLabel gathering label data with the following error " + EX);
            }

            string uFactor = String.Format("{0:0.00}", nfrcDetails[0].uFactor);
            string SolarHeat = String.Format("{0:0.00}", nfrcDetails[0].SolarHeat);

            LabelBlock = NFRCLabel(uFactor, SolarHeat, nfrcDetails[0].LightTrans.ToString(), nfrcDetails[0].AirVal, nfrcDetails[0].Desc1, nfrcDetails[0].Desc2, nfrcDetails[0].Desc3, nfrcDetails[0].Desc4, ID);
            print print = new print();
            try
            {
                string printerAddress = "\\" + "\\" + System.Environment.MachineName.ToString() + "\\ZEBRA";
                string documentName = "NFRC Label";
                string documentText = LabelBlock;

                print.PrintToShared(printerAddress, documentText, documentName);
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine createNFRCLabel printing the label with the following error " + EX);
                MessageBox.Show("I have failed in subroutine createNFRCLabel printing the label with the following error " + EX);
            }
        }

        //Processes NFRC data into ZPLII code block
        //Logging - Enabled
        public static string NFRCLabel(string uFactor, string SolarHeat, string LightTrans, string AirVal, string desc1, string desc2, string desc3, string desc4, string ID)
        {
            StringBuilder labelData = new StringBuilder();

            string lastDigits = "";
            string lineEnd = "\r\n";
            string labelBlock = "";

            try
            {
                if (ID != "")
                {

                    lastDigits = ID.Substring(ID.Length - 3);
                    uFactor = uFactor.Replace("00.", "0.");
                    SolarHeat = SolarHeat.Replace("00.", "0.");
                    LightTrans = LightTrans.Replace("00.", "0.");

                    //Header
                    labelData.Append("^XA" + lineEnd);

                    //DATA
                    labelData.Append("^FT570,850^ABI,20,12^FD" + desc1 + "^FS" + lineEnd);
                    labelData.Append("^FT570,820^ABI,20,12^FD" + desc2 + "^FS" + lineEnd);
                    labelData.Append("^FT570,790^ABI,20,12^FD" + desc3 + "^FS" + lineEnd);
                    labelData.Append("^FT570,760^ABI,20,12^FD" + desc4 + "^FS" + lineEnd);
                    //labelData.Append("^FT680,530^ADI,50,38^FD" + SolarHeat + "^FS" + lineEnd);
                    //labelData.Append("^FT300,530^ADI,50,38^FD" + uFactor + "^FS" + lineEnd);
                    labelData.Append("^FT680,530^ADI,50,38^FD" + uFactor + "^FS" + lineEnd);
                    labelData.Append("^FT300,530^ADI,50,38^FD" + SolarHeat + "^FS" + lineEnd);
                    labelData.Append("^FT680,290^ADI,50,38^FD" + LightTrans + "^FS" + lineEnd);
                    labelData.Append("^FT110,300^GB190,8,10,b,0^FS^FX" + lineEnd); //LINE
                    labelData.Append("^FT175,15^ABI,36,18^FD" + lastDigits + "^FS" + lineEnd); //Last 3 of ID

                    //Footer
                    labelData.Append("^XZ" + lineEnd);

                    labelBlock = labelData.ToString();
                    labelData.Clear();
                }
            }
            catch (Exception EX)
            {
                log.Debug("I have failed in subroutine NFRCLabel with the following error " + EX);
                MessageBox.Show("I have failed in subroutine NFRCLabel with the following error " + EX);
            }

            return labelBlock;
        }
    }
    public class NFRCRecord
    {
        public int NFRCID { get; set; }
        public string SCHKey { get; set; }
        public double uFactor { get; set; }
        public double SolarHeat { get; set; }
        public double LightTrans { get; set; }
        public string AirVal { get; set; }
        public string Desc1 { get; set; }
        public string Desc2 { get; set; }
        public string Desc3 { get; set; }
        public string Desc4 { get; set; }
        public string GT { get; set; }
    }
}
